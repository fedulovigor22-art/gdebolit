package com.gdebolit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

private val Red = Color(0xFFFF3D5A)
private val Ink = Color(0xFF14213D)
private val Bg = Color(0xFFF7F8FC)

data class PainRecord(val place: String, val pain: Int, val type: String, val date: String)
enum class Screen { HOME, BODY, QUESTIONS, SYMPTOMS, RESULT, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GdeBolitApp() }
    }
}

@Composable fun GdeBolitApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var place by remember { mutableStateOf("Не выбрано") }
    var pain by remember { mutableIntStateOf(5) }
    var type by remember { mutableStateOf("Ноющая") }
    var start by remember { mutableStateOf("Сегодня") }
    var symptoms by remember { mutableStateOf(setOf<String>()) }
    var records by remember { mutableStateOf(listOf<PainRecord>()) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Red, background = Bg)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when(screen) {
                Screen.HOME -> Home({ screen=Screen.BODY }, { screen=Screen.HISTORY })
                Screen.BODY -> Body(place, { place=it; screen=Screen.QUESTIONS }, { screen=Screen.HOME })
                Screen.QUESTIONS -> Questions(pain,{pain=it},type,{type=it},start,{start=it},{screen=Screen.SYMPTOMS},{screen=Screen.BODY})
                Screen.SYMPTOMS -> Symptoms(symptoms,{symptoms=it},{screen=Screen.RESULT},{screen=Screen.QUESTIONS})
                Screen.RESULT -> Result(place,pain,type,start,symptoms,
                    { records=listOf(PainRecord(place,pain,type,"Сегодня"))+records; screen=Screen.HOME },
                    {screen=Screen.SYMPTOMS})
                Screen.HISTORY -> History(records,{screen=Screen.HOME})
            }
        }
    }
}

@Composable fun Header(title:String,onBack:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically) {
        if(onBack!=null) Text("‹",fontSize=36.sp,color=Ink,modifier=Modifier.pointerInput(Unit){detectTapGestures{onBack()}}.padding(end=12.dp))
        Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold,color=Ink)
    }
}

@Composable fun Home(onNew:()->Unit,onHistory:()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Spacer(Modifier.height(25.dp))
        Text("Где болит?",fontSize=38.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("GdeBolit 3D • версия 0.6",fontSize=13.sp,color=Red,fontWeight=FontWeight.Bold)
        Text("Покажите на 3D-теле, где болит.",fontSize=18.sp,color=Color.Gray,modifier=Modifier.padding(top=8.dp))
        Spacer(Modifier.height(28.dp))
        Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEFF1FF))) {
            Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                Text("🫀",fontSize=70.sp); Text("Интерактивное тело",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Ink)
                Text("Вращайте тело пальцем и нажмите на область боли",color=Color.Gray,modifier=Modifier.padding(top=6.dp))
                Spacer(Modifier.height(20.dp))
                Button(onClick=onNew,colors=ButtonDefaults.buttonColors(containerColor=Red),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().height(58.dp)){Text("ПОКАЗАТЬ, ГДЕ БОЛИТ",fontSize=17.sp)}
            }
        }
        Spacer(Modifier.height(18.dp)); OutlinedButton(onClick=onHistory,modifier=Modifier.fillMaxWidth().height(52.dp)){Text("История записей")}
        Spacer(Modifier.weight(1f))
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF3FF)),shape=RoundedCornerShape(18.dp)){
            Text("Важно: приложение не ставит диагноз. При внезапной сильной боли, потере сознания, затруднении дыхания или других опасных симптомах нужна срочная медицинская помощь.",modifier=Modifier.padding(16.dp),color=Ink)
        }
    }
}

private data class Zone(val name:String,val x:Float,val y:Float,val w:Float,val h:Float)
private val zones = listOf(
    Zone("Голова",0f,-0.82f,0.34f,0.26f),
    Zone("Грудь",0f,-0.38f,0.58f,0.32f),
    Zone("Сердце",-0.10f,-0.22f,0.16f,0.18f),
    Zone("Лёгкие",0.00f,-0.30f,0.40f,0.28f),
    Zone("Живот",0f,0.00f,0.55f,0.34f),
    Zone("Желудок",-0.10f,-0.01f,0.22f,0.20f),
    Zone("Печень",0.16f,-0.03f,0.22f,0.20f),
    Zone("Кишечник",0.00f,0.17f,0.38f,0.22f),
    Zone("Таз",0f,0.35f,0.48f,0.24f),
    Zone("Левая рука",-0.63f,-0.18f,0.25f,0.62f),
    Zone("Правая рука",0.63f,-0.18f,0.25f,0.62f),
    Zone("Левая нога",-0.25f,0.70f,0.25f,0.58f),
    Zone("Правая нога",0.25f,0.70f,0.25f,0.58f)
)

@Composable fun Body(place:String,onPick:(String)->Unit,onBack:()->Unit) {
    var selected by remember { mutableStateOf(place) }
    Column(Modifier.fillMaxSize()) {
        Header("1. Где болит?",onBack)
        Text("Вращайте 3D-тело пальцем. Нажмите на орган или область боли.",modifier=Modifier.padding(horizontal=20.dp),color=Color.Gray)
        Box(Modifier.fillMaxWidth().weight(1f).padding(8.dp),contentAlignment=Alignment.Center) {
            AndroidView(factory = { ctx -> ThreeDBodyView(ctx) { zone -> selected=zone; onPick(zone) } }, modifier=Modifier.fillMaxSize())
            Column(Modifier.align(Alignment.BottomCenter),horizontalAlignment=Alignment.CenterHorizontally) {
                Text("↔ Проведите пальцем для вращения 3D",color=Color.Gray,fontSize=13.sp)
                if(selected!="Не выбрано") Text("Выбрано: $selected",fontWeight=FontWeight.Bold,color=Red)
                Spacer(Modifier.height(10.dp))
                Button(onClick={ if(selected!="Не выбрано") onPick(selected) },modifier=Modifier.fillMaxWidth(.8f).height(54.dp),shape=RoundedCornerShape(16.dp)){Text("ВЫБРАТЬ ОБЛАСТЬ")}
            }
        }
    }
}

@Composable fun Questions(pain:Int,setPain:(Int)->Unit,type:String,setType:(String)->Unit,start:String,setStart:(String)->Unit,onNext:()->Unit,onBack:()->Unit){
    Column(Modifier.fillMaxSize().padding(20.dp)){Header("2. Расскажите подробнее",onBack)
        Text("Как болит?",fontWeight=FontWeight.Bold,color=Ink)
        Row(Modifier.fillMaxWidth().padding(vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Ноющая","Колющая","Жгучая","Давящая").forEach{x->FilterChip(selected=type==x,onClick={setType(x)},label={Text(x)})}}
        Text("Сила боли: $pain из 10",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp),color=Ink)
        Slider(value=pain.toFloat(),onValueChange={setPain(it.roundToInt())},valueRange=0f..10f,steps=9)
        Text("Когда началось?",fontWeight=FontWeight.Bold,color=Ink)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(vertical=10.dp)){listOf("Сегодня","Вчера","2–7 дней назад").forEach{x->FilterChip(selected=start==x,onClick={setStart(x)},label={Text(x)})}}
        Spacer(Modifier.weight(1f)); Button(onClick=onNext,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("ДАЛЕЕ")}
    }
}

@Composable fun Symptoms(selected:Set<String>,setSelected:(Set<String>)->Unit,onNext:()->Unit,onBack:()->Unit){
    val all=listOf("Тошнота","Рвота","Температура","Вздутие","Диарея","Запор","Потеря аппетита","Боль при движении","Боль при нажатии","Одышка","Кровь","Головокружение")
    Column(Modifier.fillMaxSize().padding(20.dp)){Header("3. Дополнительные симптомы",onBack);Text("Выберите всё, что есть",color=Color.Gray);Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f)){items(all){s->Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically){Text(s,Modifier.weight(1f),color=Ink);Checkbox(checked=s in selected,onCheckedChange={c->setSelected(if(c)selected+s else selected-s)})}}}
        Button(onClick=onNext,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("ПОЛУЧИТЬ РЕЗУЛЬТАТ")}}
}

private fun advice(place:String,symptoms:Set<String>):Pair<List<String>,List<String>>{
    val causes=when(place){
        "Сердце"->listOf("мышечная боль грудной стенки","рефлюкс/изжога","сердечно-сосудистая причина — требует срочной оценки при давящей боли, одышке или холодном поте")
        "Лёгкие"->listOf("воспаление дыхательных путей","плевральная или мышечная боль","другая причина со стороны дыхательной системы — особенно при одышке")
        "Желудок"->listOf("диспепсия или раздражение желудка","рефлюкс/изжога","воспалительное или другое заболевание ЖКТ")
        "Печень"->listOf("нарушение работы желчевыводящих путей","воспалительные или другие заболевания печени","мышечная/реберная боль может ощущаться в той же области")
        "Кишечник"->listOf("газообразование и функциональные нарушения кишечника","запор или диарея","инфекционный или воспалительный процесс — зависит от симптомов")
        "Грудь"->listOf("мышечное напряжение или воспаление","рефлюкс/изжога","сердечно-сосудистая причина — её важно исключить при тревожных симптомах")
        "Живот","Таз"->listOf("нарушение пищеварения, газообразование","раздражение желудка или кишечника","инфекция или воспалительный процесс — зависит от симптомов")
        "Голова"->listOf("головная боль напряжения","мигрень","обезвоживание, недосып или другая причина")
        "Спина"->listOf("мышечное перенапряжение","проблема с позвоночником/нервом","реже — причина со стороны внутренних органов")
        else->listOf("мышечная или суставная причина","перегрузка или небольшая травма","воспалительный процесс — зависит от сопутствующих симптомов")
    }
    val actions=mutableListOf<String>()
    if("Вздутие" in symptoms || "Запор" in symptoms){actions.add("Пейте достаточно жидкости и постепенно добавляйте пищевые волокна, если они обычно вам подходят.") }
    if("Диарея" in symptoms || "Рвота" in symptoms){actions.add("Следите за питьём; при потере жидкости используйте раствор для пероральной регидратации по инструкции.") }
    if(actions.isEmpty()) actions.add("Покой, щадящая нагрузка и наблюдение за динамикой симптомов.")
    actions.add("Если боль сохраняется, повторяется или усиливается — обратитесь к врачу для очной оценки.")
    return causes to actions
}

@Composable fun Result(place:String,pain:Int,type:String,start:String,symptoms:Set<String>,onSave:()->Unit,onBack:()->Unit){
    val urgent=pain>=8 || "Кровь" in symptoms || "Одышка" in symptoms || ("Грудь"==place && ("Одышка" in symptoms || "Головокружение" in symptoms))
    val (causes,actions)=advice(place,symptoms)
    Column(Modifier.fillMaxSize().padding(20.dp)){Header("Результат",onBack)
        LazyColumn(Modifier.weight(1f)){
            item{
                Card(colors=CardDefaults.cardColors(containerColor=if(urgent)Color(0xFFFFE8EA) else Color(0xFFFFF4DE)),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){
                    Column(Modifier.padding(18.dp)){Text(if(urgent)"⚠️ Нужна повышенная осторожность" else "Возможные направления",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
                        Text(if(urgent)"При сильной боли, одышке, крови, обмороке или резком ухудшении состояния нужна срочная медицинская оценка." else "Это не диагноз. Причину боли можно определить только с учётом осмотра и, при необходимости, обследований.",modifier=Modifier.padding(top=8.dp),color=Ink)}
                }
                Spacer(Modifier.height(16.dp)); Text("Возможные причины",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Ink)
            }
            items(causes){Text("• $it",modifier=Modifier.padding(vertical=6.dp),color=Color.DarkGray)}
            item{Spacer(Modifier.height(10.dp));Text("Что можно сделать сейчас",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Ink)}
            items(actions){Text("✓ $it",modifier=Modifier.padding(vertical=6.dp),color=Color.DarkGray)}
            item{Spacer(Modifier.height(12.dp));Text("Данные: $place · $pain/10 · $type · начало: $start\nСимптомы: ${if(symptoms.isEmpty())"нет отмеченных" else symptoms.joinToString()}",color=Color.Gray,fontSize=13.sp)}
        }
        Spacer(Modifier.height(10.dp));Button(onClick=onSave,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("СОХРАНИТЬ ЗАПИСЬ")}
    }
}

@Composable fun History(records:List<PainRecord>,onBack:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Header("История",onBack);if(records.isEmpty())Text("Записей пока нет. Создайте первую запись.",color=Color.Gray,modifier=Modifier.padding(top=20.dp)) else LazyColumn{items(records){r->Card(Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text(r.place,fontWeight=FontWeight.Bold,color=Ink);Text("${r.pain}/10 · ${r.type} · ${r.date}",color=Color.Gray)}}}}}}
