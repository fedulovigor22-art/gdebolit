package com.gdebolit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(new MedicalView(this)); }

    static class MedicalView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); Path path = new Path();
        int screen = 0; // 0 home, 1 body, 2 result, 3 folk
        boolean front = true; float px=-1, py=-1; String region="";
        int navy=Color.rgb(10,16,31), card=Color.rgb(22,31,52), blue=Color.rgb(48,139,226), pink=Color.rgb(255,59,92), white=Color.WHITE, muted=Color.rgb(185,193,207);
        MedicalView(Context c){ super(c); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); setFocusable(true); }
        float d(float v){return v*getResources().getDisplayMetrics().density;}
        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(d(size));p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,d(x),d(y),p);}
        void rr(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(d(l),d(t),d(r),d(b),d(rad),d(rad),p);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); c.drawColor(navy); if(screen==0)home(c); else if(screen==1)body(c); else if(screen==2)result(c); else folk(c); }

        void header(Canvas c,String title,String sub){
            txt(c,"ГДЕ БОЛИТ?",20,35,27,white,true); txt(c,title,20,67,20,white,true); if(sub!=null)txt(c,sub,20,91,13,muted,false);
        }
        void home(Canvas c){
            header(c,"Выберите часть тела","Укажите область боли — спереди или сзади");
            rr(c,18,115,342,275,22,Color.rgb(30,84,140));
            drawMiniPerson(c,180,195,true); txt(c,"ПЕРЕДНЯЯ ЧАСТЬ",62,250,18,white,true); txt(c,"Нажать для выбора области",62,270,12,Color.rgb(220,235,255),false);
            rr(c,18,295,342,455,22,Color.rgb(70,54,125));
            drawMiniPerson(c,180,375,false); txt(c,"ЗАДНЯЯ ЧАСТЬ",62,430,18,white,true); txt(c,"Спина, позвоночник, ноги, руки",62,450,12,Color.rgb(230,220,255),false);
            rr(c,18,475,342,555,18,card); txt(c,"🌿  Народные средства",35,505,17,white,true); txt(c,"Травы, настои, питание и процедуры",35,530,12,muted,false);
            rr(c,18,570,342,635,18,card); txt(c,"ℹ  Симптомы и что делать",35,598,17,white,true); txt(c,"Справочная информация",35,620,12,muted,false);
            bottom(c,0);
        }
        void bottom(Canvas c,int active){
            p.setColor(Color.rgb(16,23,40));c.drawRect(0,d(650),getWidth(),getHeight(),p);
            txt(c,"⌂",45,682,25,active==0?white:muted,true); txt(c,"Главная",25,705,10,active==0?white:muted,false);
            txt(c,"◉",135,682,22,active==1?white:muted,true); txt(c,"Где болит",112,705,10,active==1?white:muted,false);
            txt(c,"✚",225,682,22,active==2?white:muted,true); txt(c,"Что делать",203,705,10,active==2?white:muted,false);
            txt(c,"✿",310,682,22,active==3?white:muted,true); txt(c,"Народные",288,705,10,active==3?white:muted,false);
        }
        void body(Canvas c){
            txt(c,"‹",18,42,38,white,false); txt(c,front?"Передняя часть тела":"Задняя часть тела",60,37,21,white,true); txt(c,"⟳",330,40,24,white,false);
            txt(c,"Нажмите прямо на место боли",78,70,13,muted,false);
            rr(c,18,82,165,118,18,front?blue:card); txt(c,"ПЕРЕД",67,106,14,white,true);
            rr(c,177,82,324,118,18,!front?blue:card); txt(c,"ЗАД",236,106,14,white,true);
            drawBody(c,171,365,front);
            if(px>0){ p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(4));p.setColor(pink);c.drawCircle(d(px),d(py),d(15),p);p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(90,255,59,92));c.drawCircle(d(px),d(py),d(9),p); }
            if(!region.isEmpty()){ rr(c,25,520,335,585,18,Color.WHITE);txt(c,region,45,548,16,Color.rgb(25,35,55),true);txt(c,"Нажмите «Подтвердить область»",45,570,12,Color.DKGRAY,false); }
            rr(c,25,595,335,645,17,pink);txt(c,"ПОДТВЕРДИТЬ ОБЛАСТЬ",74,626,16,white,true);
            bottom(c,1);
        }
        void drawBody(Canvas c,float cx,float cy,boolean f){
            float s=1.0f;
            // silhouette
            p.setColor(Color.rgb(83,76,77));p.setStyle(Paint.Style.FILL);
            c.drawCircle(d(cx),d(cy-245),d(38),p); rr(c,cx-25,cy-210,cx+25,cy-155,20,p.getColor());
            // torso
            path.reset(); path.moveTo(d(cx-43),d(cy-165));path.quadTo(d(cx-75),d(cy-120),d(cx-55),d(cy-20));path.quadTo(d(cx-40),d(cy+15),d(cx-28),d(cy+45));path.lineTo(d(cx+28),d(cy+45));path.quadTo(d(cx+40),d(cy+15),d(cx+55),d(cy-20));path.quadTo(d(cx+75),d(cy-120),d(cx+43),d(cy-165));path.close();c.drawPath(path,p);
            // arms
            rr(c,cx-82,cy-150,cx-48,cy+5,17,p.getColor()); rr(c,cx+48,cy-150,cx+82,cy+5,17,p.getColor());
            // legs
            rr(c,cx-42,cy+35,cx-5,cy+195,18,p.getColor()); rr(c,cx+5,cy+35,cx+42,cy+195,18,p.getColor());
            // feet
            rr(c,cx-50,cy+185,cx-3,cy+210,12,p.getColor()); rr(c,cx+3,cy+185,cx+50,cy+210,12,p.getColor());
            if(f){
                // lungs
                p.setColor(Color.rgb(212,118,133)); c.drawOval(d(cx-42),d(cy-145),d(cx-3),d(cy-72),p); c.drawOval(d(cx+3),d(cy-145),d(cx+42),d(cy-72),p);
                // heart
                p.setColor(Color.rgb(220,54,65));c.drawCircle(d(cx),d(cy-105),d(13),p);
                // liver
                p.setColor(Color.rgb(132,70,53));c.drawOval(d(cx-43),d(cy-70),d(cx+5),d(cy-35),p);
                // stomach
                p.setColor(Color.rgb(225,145,125));c.drawOval(d(cx+1),d(cy-66),d(cx+43),d(cy-30),p);
                // intestines
                p.setColor(Color.rgb(221,139,145)); for(int i=0;i<4;i++){c.drawOval(d(cx-37),d(cy-32+i*14),d(cx+37),d(cy-16+i*14),p);}
                p.setColor(Color.rgb(100,50,50)); c.drawOval(d(cx-15),d(cy+23),d(cx+15),d(cy+35),p);
            } else {
                p.setColor(Color.rgb(200,200,205));p.setStrokeWidth(d(5));p.setStyle(Paint.Style.STROKE);c.drawLine(d(cx),d(cy-160),d(cx),d(cy+35),p);
                for(int i=0;i<7;i++)c.drawLine(d(cx-23),d(cy-145+i*25),d(cx+23),d(cy-145+i*25),p);
                p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(125,70,75));c.drawOval(d(cx-40),d(cy-70),d(cx-5),d(cy-25),p);c.drawOval(d(cx+5),d(cy-70),d(cx+40),d(cy-25),p);
                p.setColor(Color.rgb(170,110,110));c.drawOval(d(cx-40),d(cy-15),d(cx+40),d(cy+35),p);
            }
        }
        void drawMiniPerson(Canvas c,float x,float y,boolean f){ drawBody(c,x,y,f); }
        void result(Canvas c){
            txt(c,"‹",18,42,38,white,false);txt(c,"Выбранная область",60,37,21,white,true);
            rr(c,20,70,340,170,20,Color.WHITE);txt(c,region.isEmpty()?"Область тела":region,40,102,20,Color.rgb(20,30,48),true);txt(c,front?"Передняя поверхность":"Задняя поверхность",40,128,13,Color.DKGRAY,false);txt(c,"Это справочная информация, не диагноз.",40,150,12,Color.DKGRAY,false);
            rr(c,20,190,340,310,20,card);txt(c,"Возможные связанные области",38,220,17,white,true);txt(c,"• мышцы и мягкие ткани",40,247,14,muted,false);txt(c,"• внутренние органы — в зависимости от зоны",40,272,14,muted,false);txt(c,"• нервные структуры",40,297,14,muted,false);
            rr(c,20,330,340,395,18,pink);txt(c,"ЧТО МОЖНО СДЕЛАТЬ",75,369,16,white,true);
            rr(c,20,415,340,540,20,card);txt(c,"Срочно обратиться за помощью",38,448,17,white,true);txt(c,"если боль сильная, внезапная, есть обморок,",38,475,13,muted,false);txt(c,"одышка, кровь или резкое ухудшение.",38,497,13,muted,false);txt(c,"При сохраняющейся боли нужна очная оценка врача.",38,523,12,white,false);
            bottom(c,2);
        }
        void folk(Canvas c){
            txt(c,"‹",18,42,38,white,false);txt(c,"Народные средства",60,37,21,white,true);txt(c,"Справочник трав и домашних способов",60,61,12,muted,false);
            String[] herbs={"Ромашка аптечная","Мята перечная","Тысячелистник","Календула","Мелисса","Имбирь"};
            int y=85; for(int i=0;i<herbs.length;i++){rr(c,18,y,342,y+62,16,i==0?Color.rgb(38,75,75):card);txt(c,"🌿",32,y+38,22,white,false);txt(c,herbs[i],70,y+28,16,white,true);txt(c,herbUse(i),70,y+49,11,muted,false);y+=70;}
            rr(c,18,520,342,625,18,Color.rgb(44,38,38));txt(c,"ВАЖНО",35,548,15,Color.rgb(255,112,112),true);txt(c,"Народные средства не заменяют диагностику",35,573,12,white,false);txt(c,"и лечение врача. При ухудшении состояния",35,593,12,white,false);txt(c,"обратитесь за медицинской помощью.",35,613,12,white,false);
            bottom(c,3);
        }
        String herbUse(int i){String[] a={"чай и настой — мягко успокаивает","чай — при спазмах и вздутии","традиционно используют как чай","наружные средства и настои","чай — успокаивающий напиток","чай — в кулинарии и как напиток"};return a[i];}

        String hitRegion(float x,float y){
            float dx=x-171, dy=y-365;
            if(dy<-195)return "Голова"; if(Math.abs(dx)>55 && dy<-40)return dx<0?"Левая рука":"Правая рука"; if(dy>35&&Math.abs(dx)<50)return dy>115?(dx<0?"Левая нога":"Правая нога"):"Нижняя часть живота";
            if(dy<-120)return "Грудь"; if(dy<-70)return "Область сердца"; if(dy<-20)return "Верх живота"; return "Живот";
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX()/getResources().getDisplayMetrics().density,y=e.getY()/getResources().getDisplayMetrics().density;
            if(screen==0){ if(y>115&&y<285){front=true;screen=1;} else if(y>295&&y<465){front=false;screen=1;} else if(y>475&&y<560){screen=3;} }
            else if(screen==1){ if(y>82&&y<125){if(x<170)front=true;else front=false;} else if(y>120&&y<520){px=x;py=y;region=hitRegion(x,y);} else if(y>585&&y<650&&!region.isEmpty()){screen=2;} }
            else if(screen==2){ if(y>330&&y<405)screen=0; else if(y>650)screen=0; }
            else if(screen==3){ if(y<55)screen=0; else if(y>650)screen=0; }
            if(y>650){ if(x>270)screen=3; else if(x>100&&x<190)screen=1; else if(x<90)screen=0; }
            invalidate();return true; }
    }
}
