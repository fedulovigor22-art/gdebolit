package com.gdebolit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769E0)
private val Red = Color(0xFFE53935)
private val LightBg = Color(0xFFF7F9FC)
private val DarkBg = Color(0xFF101318)
private val DarkCard = Color(0xFF1A1F27)

private data class Herb(val name: String, val short: String, val use: String, val caution: String)

private val herbs = listOf(
    Herb("Ромашка", "Успокаивающая трава", "Чай; мягкое применение при спазмах и дискомфорте.", "Аллергия на сложноцветные; не заменяет диагностику."),
    Herb("Мята", "Ароматная трава", "Чай; может использоваться как вспомогательный вариант при спазмах и тошноте.", "При изжоге может ухудшать симптомы у некоторых людей."),
    Herb("Мелисса", "Успокаивающая трава", "Чай; как вспомогательный вариант при напряжении и стрессовом компоненте боли.", "Осторожность при индивидуальной непереносимости и взаимодействиях с лекарствами."),
    Herb("Имбирь", "Корень", "Настой/чай; может быть полезен как вспомогательный вариант при тошноте.", "Может раздражать желудок и влиять на риск кровотечения с некоторыми препаратами."),
    Herb("Шиповник", "Источник растительных компонентов", "Настой как напиток; не является специфическим лечением боли.", "Кислый напиток может не подходить при некоторых желудочных симптомах."),
    Herb("Календула", "Растительное средство", "Наружное применение в подходящих формах; внутрь — только после проверки противопоказаний.", "Аллергия на сложноцветные; возможны лекарственные взаимодействия.")
)

enum class Screen { HOME, FRONT, BACK, FRONT_POINT, BACK_POINT, INTENSITY, DESCRIPTION, DETAILS, RECOMMENDATIONS, HERBS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GdeBolitApp() }
    }
}

@Composable
fun GdeBolitApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selected by remember { mutableStateOf("Живот (по центру)") }
    var intensity by remember { mutableStateOf("Очень сильная") }
    var description by remember { mutableStateOf("Ноющая") }
    var darkTheme by remember { mutableStateOf(false) }

    val colors = if (darkTheme) darkColorScheme(primary = Blue, background = DarkBg, surface = DarkCard) else lightColorScheme(primary = Blue, background = LightBg)
    MaterialTheme(colorScheme = colors) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                when (screen) {
                    Screen.HOME -> Home(darkTheme, { darkTheme = !darkTheme }, { screen = it })
                    Screen.FRONT -> BodyPicker(false, selected) { selected = it; screen = Screen.FRONT_POINT }
                    Screen.BACK -> BodyPicker(true, selected) { selected = it; screen = Screen.BACK_POINT }
                    Screen.FRONT_POINT, Screen.BACK_POINT -> PointScreen(screen == Screen.BACK_POINT, selected, { screen = Screen.INTENSITY }, { screen = if (screen == Screen.BACK_POINT) Screen.BACK else Screen.FRONT })
                    Screen.INTENSITY -> IntensityScreen(intensity, { intensity = it }, { screen = Screen.DESCRIPTION })
                    Screen.DESCRIPTION -> DescriptionScreen(description, { description = it }, { screen = Screen.DETAILS })
                    Screen.DETAILS -> DetailsScreen(selected, intensity, description) { screen = Screen.RECOMMENDATIONS }
                    Screen.RECOMMENDATIONS -> Recommendations(selected, intensity, { screen = Screen.HERBS }, { screen = Screen.HOME })
                    Screen.HERBS -> HerbCatalog(selected, { screen = Screen.RECOMMENDATIONS })
                }
            }
        }
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) action() else Icon(Icons.Default.Info, null, tint = Blue)
    }
}

@Composable
fun Home(dark: Boolean, toggleTheme: () -> Unit, go: (Screen) -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("ГдеБолит", fontSize = 34.sp, fontWeight = FontWeight.Bold); Text("Укажите место боли на теле человека", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = toggleTheme) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Тема") }
        }
        Spacer(Modifier.height(30.dp))
        ChoiceCard("Вид спереди", "Выбрать на передней стороне тела", Icons.Default.Person) { go(Screen.FRONT) }
        Spacer(Modifier.height(16.dp))
        ChoiceCard("Вид сзади", "Выбрать на задней стороне тела", Icons.Default.PersonOutline) { go(Screen.BACK) }
        Spacer(Modifier.height(16.dp))
        ChoiceCard("🌿 Каталог трав", "Справочник растений и безопасных ориентиров", Icons.Default.MenuBook) { go(Screen.HERBS) }
        Spacer(Modifier.weight(1f))
        Text(if (dark) "Тёмная тема" else "Светлая тема", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        BottomNav()
    }
}

@Composable
fun ChoiceCard(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = click), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(40.dp)); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Blue, fontWeight = FontWeight.Bold); Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
fun BodyPicker(back: Boolean, selected: String, choose: (String) -> Unit) {
    Header(if (back) "Вид сзади" else "Вид спереди")
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.Center) {
            val res = if (back) R.drawable.body_back else R.drawable.body_front
            Box(Modifier.fillMaxHeight().width(250.dp), contentAlignment = Alignment.Center) {
                Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                if (!back) {
                    Marker(Alignment.TopCenter, "Голова") { choose("Голова") }
                    Marker(Alignment.Center, "Живот") { choose("Живот (по центру)") }
                    Marker(Alignment.BottomCenter, "Нога") { choose("Нога") }
                } else {
                    Marker(Alignment.TopCenter, "Голова") { choose("Голова") }
                    Marker(Alignment.Center, "Поясница") { choose("Поясница (по центру)") }
                    Marker(Alignment.BottomCenter, "Нога") { choose("Нога") }
                }
            }
        }
        Text("Выберите область, где у вас болит", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { choose(selected) }, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Далее") }
    }
}

@Composable
fun Marker(alignment: Alignment, label: String, click: () -> Unit) {
    Box(Modifier.fillMaxSize().wrapContentSize(alignment).padding(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = .94f)).clickable(onClick = click).padding(horizontal = 10.dp, vertical = 6.dp)) { Text(label, fontSize = 11.sp) }
}

@Composable
fun PointScreen(back: Boolean, selected: String, onNext: () -> Unit, onBack: () -> Unit) {
    Header(if (back) "Выбор точки боли: сзади" else "Выбор точки боли: спереди", onBack)
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Image(painterResource(if (back) R.drawable.body_back else R.drawable.body_front), null, Modifier.fillMaxHeight().width(280.dp), contentScale = ContentScale.Fit)
            Box(Modifier.size(76.dp).clip(CircleShape).background(Red.copy(alpha = .30f)), contentAlignment = Alignment.Center) { Box(Modifier.size(34.dp).clip(CircleShape).background(Red)) }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(14.dp)) { Text("Выбранная область:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(selected, fontWeight = FontWeight.Bold) }
        }
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Далее") }
    }
}

@Composable
fun IntensityScreen(value: String, onChange: (String) -> Unit, next: () -> Unit) {
    Header("Интенсивность боли")
    val vals = listOf("Нет боли", "Слабая", "Умеренная", "Сильная", "Очень сильная")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Насколько сильная боль?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        vals.forEach { v ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onChange(v) }, colors = CardDefaults.cardColors(if (v == value) Blue.copy(alpha = .12f) else MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(v, Modifier.weight(1f)); RadioButton(v == value, onClick = { onChange(v) }) }
            }
        }
        Spacer(Modifier.weight(1f)); Button(next, Modifier.fillMaxWidth()) { Text("Далее") }
    }
}

@Composable
fun DescriptionScreen(value: String, onChange: (String) -> Unit, next: () -> Unit) {
    Header("Описание боли")
    val items = listOf("Ноющая", "Острая", "Тянущая", "Пульсирующая", "Жгучая", "Давящая")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Как описать вашу боль?", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        items.forEach { v -> ListItem(headlineContent = { Text(v) }, leadingContent = { Icon(Icons.Default.FavoriteBorder, null) }, trailingContent = { RadioButton(selected = value == v, onClick = { onChange(v) }) }, modifier = Modifier.clickable { onChange(v) }) }
        Spacer(Modifier.weight(1f)); Button(next, Modifier.fillMaxWidth()) { Text("Далее") }
    }
}

@Composable
fun DetailsScreen(selected: String, intensity: String, description: String, next: () -> Unit) {
    Header("Детали боли")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(16.dp)) { Image(painterResource(R.drawable.body_front), null, Modifier.size(90.dp)); Spacer(Modifier.width(12.dp)); Column { Text("Выбранная область:"); Text(selected, fontWeight = FontWeight.Bold); Text("Интенсивность: $intensity", fontSize = 13.sp); Text("Характер: $description", fontSize = 13.sp) } } }
        Spacer(Modifier.height(12.dp))
        listOf("Когда началась боль?", "Что усиливает боль?", "Что уменьшает боль?", "Есть ли другие симптомы?").forEach { ListItem(headlineContent = { Text(it) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) }) }
        Spacer(Modifier.weight(1f)); Button(next, Modifier.fillMaxWidth()) { Text("Далее") }
    }
}

@Composable
fun Recommendations(selected: String, intensity: String, herbsNext: () -> Unit, home: () -> Unit) {
    Header("Рекомендации")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Ориентир по выбранной области: $selected", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Интенсивность: $intensity", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        if (intensity == "Очень сильная" || intensity == "Сильная") {
            listOf("Не откладывать медицинскую оценку", "При резком ухудшении или опасных симптомах обратиться за неотложной помощью", "Не использовать травы вместо обследования").forEach { ListItem(headlineContent = { Text(it) }, leadingContent = { Icon(Icons.Default.Warning, null, tint = Red) }) }
        } else {
            listOf("Наблюдать за симптомами", "Отдых и щадящий режим при необходимости", "При сохранении или усилении боли обратиться к врачу").forEach { ListItem(headlineContent = { Text(it) }, leadingContent = { Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF27AE60)) }) }
        }
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceVariant)) { Column(Modifier.padding(14.dp)) { Text("🌿 Фитотерапия", fontWeight = FontWeight.Bold); Text("Ниже можно открыть каталог трав и посмотреть подходящие ориентиры. Травы не являются заменой диагностике и назначению врача.", fontSize = 13.sp) } }
        Spacer(Modifier.height(12.dp))
        Button(herbsNext, Modifier.fillMaxWidth()) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Подобрать травы / открыть каталог") }
        OutlinedButton(home, Modifier.fillMaxWidth()) { Text("На главную") }
    }
}

@Composable
fun HerbCatalog(selected: String, back: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = herbs.filter { it.name.contains(query, true) || it.short.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Header("Каталог трав", back, action = { Text("🌿", fontSize = 24.sp) })
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(8.dp), label = { Text("Поиск травы") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        }
        Text("Ориентир для области: $selected", Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            items(filtered) { herb ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(herb.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(herb.short, color = Blue)
                        Spacer(Modifier.height(5.dp)); Text("Как используется: ${herb.use}", fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp)); Text("Осторожность: ${herb.caution}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNav() {
    Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceAround) {
        Text("⌂\nГлавная", color = Blue, fontSize = 12.sp); Text("◷\nИстория", fontSize = 12.sp); Text("ⓘ\nО приложении", fontSize = 12.sp)
    }
}
