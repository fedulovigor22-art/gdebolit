package com.gdebolit.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min

/** Full human anatomy view drawn with Android Canvas (no OpenGL dependency). */
class ThreeDBodyView(context: Context, private val onPick: (String) -> Unit) : View(context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private var rotation = 0f
    private var lastX = 0f
    private var moved = false

    private fun x(cx: Float, local: Float, scale: Float, turn: Float): Float = cx + local * scale * cos(Math.toRadians(turn.toDouble())).toFloat()
    private fun sx(local: Float, scale: Float, turn: Float): Float = local * scale * (0.38f + 0.62f * abs(cos(Math.toRadians(turn.toDouble())).toFloat()))
    private fun fill(c: Int, a: Int = 255) { fill.style=Paint.Style.FILL; fill.color=c; fill.alpha=a }
    private fun line(c: Int, width: Float, a: Int = 255) { stroke.color=c; stroke.strokeWidth=width; stroke.alpha=a }

    override fun onDraw(c: Canvas) {
        super.onDraw(c); c.drawColor(Color.rgb(247,248,252))
        val w=width.toFloat(); val h=height.toFloat(); val scale=min(w/430f,h/760f).coerceIn(.48f,.95f); val cx=w/2f; val cy=h/2f+8f
        val facing=abs(cos(Math.toRadians(rotation.toDouble())).toFloat()); val oa=(55+190*facing).toInt().coerceIn(55,245)
        fill(Color.argb(24,20,33,61)); c.drawOval(RectF(cx-125*scale,cy+330*scale,cx+125*scale,cy+350*scale),fill)

        val skin=Color.rgb(218,181,164); val light=Color.rgb(235,207,194); val dark=Color.rgb(171,126,111); val outline=Color.rgb(105,80,78)
        // Head, ears, neck.
        val hx=cx; val hw=sx(72f,scale,rotation)
        fill(light,205); c.drawOval(RectF(hx-hw,cy-342*scale,hx+hw,cy-250*scale),fill)
        line(outline,2.5f*scale,135); c.drawOval(RectF(hx-hw,cy-342*scale,hx+hw,cy-250*scale),stroke)
        fill(skin,190); c.drawOval(RectF(x(cx,-39,scale,rotation)-12*scale,cy-312*scale,x(cx,-39,scale,rotation)+12*scale,cy-278*scale),fill); c.drawOval(RectF(x(cx,39,scale,rotation)-12*scale,cy-312*scale,x(cx,39,scale,rotation)+12*scale,cy-278*scale),fill)
        fill(dark,150); c.drawRoundRect(RectF(cx-19*scale,cy-265*scale,cx+19*scale,cy-225*scale),12*scale,12*scale,fill)

        // Torso silhouette.
        val tw=sx(102f,scale,rotation); fill(Color.argb(150,skin.red(),skin.green(),skin.blue())); c.drawOval(RectF(cx-tw,cy-238*scale,cx+tw,cy+108*scale),fill)
        line(outline,2.8f*scale,130); c.drawOval(RectF(cx-tw,cy-238*scale,cx+tw,cy+108*scale),stroke)

        fun arm(side:Float) {
            val sh=x(cx,side*93,scale,rotation); val el=x(cx,side*139,scale,rotation); val hand=x(cx,side*153,scale,rotation)
            fill(skin,155); c.drawOval(RectF(sh-25*scale,cy-220*scale,sh+25*scale,cy-88*scale),fill); c.drawOval(RectF(el-18*scale,cy-115*scale,el+18*scale,cy+20*scale),fill); c.drawOval(RectF(hand-15*scale,cy+5*scale,hand+15*scale,cy+55*scale),fill)
            line(outline,2.3f*scale,105); c.drawOval(RectF(sh-25*scale,cy-220*scale,sh+25*scale,cy-88*scale),stroke); c.drawOval(RectF(el-18*scale,cy-115*scale,el+18*scale,cy+20*scale),stroke); c.drawOval(RectF(hand-15*scale,cy+5*scale,hand+15*scale,cy+55*scale),stroke)
            line(dark,1.5f*scale,110); for(i in -1..1)c.drawLine(hand+i*5*scale,cy+18*scale,hand+i*5*scale,cy+43*scale,stroke)
        }
        arm(-1f); arm(1f)
        fun leg(side:Float) {
            val hip=x(cx,side*48,scale,rotation); val knee=x(cx,side*54,scale,rotation); val foot=x(cx,side*56,scale,rotation)
            fill(skin,160); c.drawOval(RectF(hip-30*scale,cy+72*scale,hip+30*scale,cy+210*scale),fill); c.drawOval(RectF(knee-23*scale,cy+185*scale,knee+23*scale,cy+320*scale),fill); c.drawOval(RectF(foot-25*scale,cy+306*scale,foot+33*scale,cy+346*scale),fill)
            line(outline,2.5f*scale,110); c.drawOval(RectF(hip-30*scale,cy+72*scale,hip+30*scale,cy+210*scale),stroke); c.drawOval(RectF(knee-23*scale,cy+185*scale,knee+23*scale,cy+320*scale),stroke); c.drawOval(RectF(foot-25*scale,cy+306*scale,foot+33*scale,cy+346*scale),stroke)
        }
        leg(-1f); leg(1f)

        // Organs: lungs, heart, liver, stomach, spleen, kidneys, bowel, bladder.
        fun organ(local:Float,y:Float,ww:Float,hh:Float,color:Int) { val ox=x(cx,local,scale,rotation); val ow=sx(ww/2,scale,rotation); fill(color,oa); c.drawOval(RectF(ox-ow,cy+(y-hh/2)*scale,ox+ow,cy+(y+hh/2)*scale),fill); line(Color.rgb(95,65,65),1.7f*scale,(oa*.55f).toInt()); c.drawOval(RectF(ox-ow,cy+(y-hh/2)*scale,ox+ow,cy+(y+hh/2)*scale),stroke) }
        organ(-47,-128,72,125,Color.rgb(225,130,140)); organ(47,-128,72,125,Color.rgb(225,130,140));
        line(Color.rgb(213,154,143),7*scale,oa); c.drawLine(cx,cy-224*scale,cx,cy-145*scale,stroke)
        organ(0,-116,48,58,Color.rgb(194,54,65)); organ(31,-10,98,65,Color.rgb(145,70,43)); organ(-27,0,66,58,Color.rgb(236,153,105)); organ(58,7,25,43,Color.rgb(110,64,65)); organ(13,22,22,25,Color.rgb(181,164,42)); organ(-59,57,29,48,Color.rgb(152,73,68)); organ(59,57,29,48,Color.rgb(152,73,68))
        val bowel=Path(); val bx=cx; bowel.moveTo(bx-72*scale,cy+52*scale); bowel.cubicTo(bx-88*scale,cy+105*scale,bx-78*scale,cy+155*scale,bx-52*scale,cy+175*scale); bowel.cubicTo(bx-20*scale,cy+198*scale,bx+18*scale,cy+195*scale,bx+48*scale,cy+176*scale); bowel.cubicTo(bx+80*scale,cy+155*scale,bx+86*scale,cy+105*scale,bx+70*scale,cy+55*scale); line(Color.rgb(201,79,83),25*scale*maxOf(.45f,facing),oa); c.drawPath(bowel,stroke)
        val small=Path(); small.moveTo(bx-48*scale,cy+105*scale); small.cubicTo(bx-18*scale,cy+78*scale,bx+18*scale,cy+142*scale,bx+48*scale,cy+108*scale); small.cubicTo(bx+20*scale,cy+75*scale,bx-10*scale,cy+150*scale,bx-42*scale,cy+122*scale); line(Color.rgb(237,143,139),13*scale*maxOf(.45f,facing),oa); c.drawPath(small,stroke)
        organ(0,220,38,46,Color.rgb(195,104,105))

        // Highlight and rotation hint.
        line(Color.WHITE,5*scale,(40+90*facing).toInt()); c.drawLine(cx-tw*.62f,cy-220*scale,cx-tw*.82f,cy+50*scale,stroke)
        fill(Color.argb(80,255,255,255)); c.drawOval(RectF(cx-30*scale,cy-330*scale,cx-3*scale,cy-275*scale),fill)
        if(moved){ fill(Color.argb(145,90,90,90)); fill.textSize=13f*resources.displayMetrics.scaledDensity; fill.textAlign=Paint.Align.CENTER; c.drawText("Поворот: ${rotation.toInt()}°",cx,h-8,fill) }
    }

    override fun onTouchEvent(e:MotionEvent):Boolean=when(e.actionMasked){
        MotionEvent.ACTION_DOWN->{lastX=e.x;moved=false;true}
        MotionEvent.ACTION_MOVE->{val dx=e.x-lastX;if(abs(dx)>2)moved=true;rotation=(rotation+dx*.7f)%360f;lastX=e.x;invalidate();true}
        MotionEvent.ACTION_UP->{if(!moved)onPick(hitTest(e.x,e.y));true}
        else->true
    }
    private fun hitTest(px:Float,py:Float):String{
        val s=min(width/430f,height/760f).coerceIn(.48f,.95f); val cx=width/2f; val cy=height/2f+8; val co=cos(Math.toRadians(rotation.toDouble())).toFloat(); val lx=(px-cx)/(s*(if(abs(co)<.38f)if(co<0)-.38f else .38f else co)); val y=(py-cy)/s
        return when{ y < -245 -> "Голова"; y in -220f..-70f && abs(lx)<80 -> "Лёгкие"; y in -145f..-80f && abs(lx)<38 -> "Сердце"; y in -55f..35f && lx<15 -> "Желудок"; y in -55f..40f && lx>=15 -> "Печень"; y in 30f..115f && abs(lx)<78 -> "Кишечник"; y in 25f..120f && lx < -105 -> "Левая рука"; y in 25f..120f && lx > 105 -> "Правая рука"; y>115f&&lx< -18 -> "Левая нога"; y>115f -> "Правая нога"; y<15 -> "Грудь"; y<145 -> "Живот"; else -> "Таз" }
    }
}
