package com.gdebolit.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.util.Locale
import kotlin.math.min

private data class Herb(
    val name: String,
    val latin: String,
    val description: String,
    val application: String,
    val caution: String,
    val areas: Set<String>
)

private data class BodyZone(val name: String, val rect: RectF)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var dark = false
    private var front = true
    private var selectedZone = ""
    private var painType = "Ноющая"
    private var painStrength = 5
    private var details = ""

    private val herbs = listOf(
        Herb("Ромашка аптечная", "Matricaria chamomilla", "Традиционно используется как травяной напиток при лёгком пищеварительном дискомфорте.", "Настой: 1 ч. л. сухих цветков на 200 мл горячей воды, дать настояться и остудить до комфортной температуры.", "Не использовать при аллергии на сложноцветные.", setOf("Живот", "Горло")),
        Herb("Мята перечная", "Mentha × piperita", "Традиционно применяется как чай при лёгком спазматическом и диспепсическом дискомфорте.", "Обычный травяной чай в пищевых количествах.", "Может усиливать симптомы рефлюкса; при выраженной изжоге лучше отказаться.", setOf("Живот")),
        Herb("Мелисса лекарственная", "Melissa officinalis", "Травяной напиток с успокаивающим и расслабляющим традиционным применением.", "Настой/чай в обычных пищевых количествах.", "При беременности, хронических заболеваниях или приёме лекарств нужна консультация специалиста.", setOf("Голова", "Грудь", "Живот")),
        Herb("Имбирь", "Zingiber officinale", "Пищевой продукт и напиток, который может помогать при тошноте.", "Добавление в пищу или чай в небольшом пищевом количестве.", "Осторожность при приёме антикоагулянтов и заболеваниях ЖКТ.", setOf("Живот")),
        Herb("Шалфей", "Salvia officinalis", "Традиционно используется для местного ухода при дискомфорте в горле.", "Полоскание охлаждённым настоем; не глотать концентрированные эфирные масла.", "Не использовать эфирное масло внутрь; при беременности нужна консультация специалиста.", setOf("Горло")),
        Herb("Календула", "Calendula officinalis", "Традиционное наружное применение для ухода за кожей.", "Наружное применение готового средства по инструкции производителя.", "Не использовать при аллергии на сложноцветные.", setOf("Рука", "Нога", "Кожа")),
        Herb("Тысячелистник", "Achillea millefolium", "Традиционно применяется как травяной напиток при лёгком пищеварительном дискомфорте.", "Только в виде готового чая/настоя с соблюдением инструкции.", "Не применять при беременности без рекомендации врача; возможны аллергические реакции.", setOf("Живот")),
        Herb("Липа", "Tilia cordata", "Тёплый травяной напиток при простудном дискомфорте.", "Обычный травяной чай в пищевых количествах.", "При высокой температуре, одышке или ухудшении состояния нужна медицинская оценка.", setOf("Горло", "Грудь"))
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        dark = getPreferences(0).getBoolean("dark", false)
        showHome()
    }

    private fun bg() = if (dark) Color.rgb(11, 15, 22) else Color.rgb(248, 250, 253)
    private fun card() = if (dark) Color.rgb(23, 29, 39) else Color.WHITE
    private fun fg() = if (dark) Color.WHITE else Color.rgb(18, 31, 57)
    private fun muted() = if (dark) Color.rgb(180, 188, 201) else Color.rgb(80, 91, 110)
    private fun blue() = Color.rgb(18, 103, 218)
    private fun accent() = Color.rgb(255, 55, 88)

    private fun base(): LinearLayout {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(18, 12, 18, 10)
        root.setBackgroundColor(bg())
        return root
    }

    private fun text(value: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(fg())
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(4, 6, 4, 6)
    }

    private fun button(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(fg())
        setOnClickListener { click() }
        minHeight = 50
    }

    private fun primary(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(blue())
        setOnClickListener { click() }
        minHeight = 54
    }

    private fun header(title: String, back: (() -> Unit)? = { showHome() }): LinearLayout {
        val h = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val b = button("‹") { back?.invoke() }
        h.addView(b, LinearLayout.LayoutParams(54, 54))
        h.addView(text(title, 22f, true), LinearLayout.LayoutParams(0, 54, 1f))
        h.addView(button(if (dark) "☀" else "☾") { toggleTheme() }, LinearLayout.LayoutParams(54, 54))
        return h
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER }
        nav.addView(button("⌂\nГлавная") { showHome() }, LinearLayout.LayoutParams(0, 62, 1f))
        nav.addView(button("🌿\nКаталог трав") { showHerbs("") }, LinearLayout.LayoutParams(0, 62, 1f))
        nav.addView(button("◷\nИстория") { showInfo() }, LinearLayout.LayoutParams(0, 62, 1f))
        nav.addView(button("⚙\nНастройки") { showSettings() }, LinearLayout.LayoutParams(0, 62, 1f))
        return nav
    }

    private fun toggleTheme() {
        dark = !dark
        getPreferences(0).edit().putBoolean("dark", dark).apply()
        showHome()
    }

    private fun showHome() {
        base(); setContentView(root)
        root.addView(text("ГдеБолит", 31f, true))
        root.addView(text("Укажите место боли на теле человека", 17f))
        root.addView(button("👤  Вид спереди\nВыбрать область на передней стороне тела") { showBody(true) })
        root.addView(button("👤  Вид сзади\nВыбрать область на задней стороне тела") { showBody(false) })
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(primary("🌿  Каталог трав") { showHerbs("") })
        root.addView(bottomNav())
    }

    private fun showBody(isFront: Boolean) {
        front = isFront
        base(); setContentView(root)
        root.addView(header("Выбор области"))
        val switch = LinearLayout(this)
        switch.addView(primary("Вид спереди") { showBody(true) }, LinearLayout.LayoutParams(0, 48, 1f))
        switch.addView(button("Вид сзади") { showBody(false) }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(switch)
        root.addView(text("Нажмите прямо на область, где болит", 16f))
        val body = BodyView(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text(if (selectedZone.isBlank()) "Область не выбрана" else "Выбрано: $selectedZone", 17f, true))
        root.addView(primary("Далее") {
            if (selectedZone.isBlank()) Toast.makeText(this, "Сначала выберите область", Toast.LENGTH_SHORT).show() else showPain()
        })
    }

    private inner class BodyView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val zones = ArrayList<BodyZone>()

        override fun onDraw(c: Canvas) {
            zones.clear()
            val w = width.toFloat(); val h = height.toFloat()
            val scale = min(w / 330f, h / 620f)
            val cx = w / 2f; val top = 12f
            paint.style = Paint.Style.FILL
            paint.color = card()
            c.drawRoundRect(RectF(8f, 8f, w - 8f, h - 8f), 24f, 24f, paint)

            val skin = if (dark) Color.rgb(229, 184, 156) else Color.rgb(242, 202, 177)
            paint.color = skin
            c.drawCircle(cx, top + 48 * scale, 32 * scale, paint)
            c.drawRoundRect(RectF(cx - 16 * scale, top + 76 * scale, cx + 16 * scale, top + 112 * scale), 12f, 12f, paint)
            c.drawRoundRect(RectF(cx - 58 * scale, top + 104 * scale, cx + 58 * scale, top + 326 * scale), 30f, 30f, paint)
            c.drawRoundRect(RectF(cx - 100 * scale, top + 112 * scale, cx - 68 * scale, top + 302 * scale), 16f, 16f, paint)
            c.drawRoundRect(RectF(cx + 68 * scale, top + 112 * scale, cx + 100 * scale, top + 302 * scale), 16f, 16f, paint)
            c.drawRoundRect(RectF(cx - 50 * scale, top + 316 * scale, cx - 7 * scale, top + 585 * scale), 20f, 20f, paint)
            c.drawRoundRect(RectF(cx + 7 * scale, top + 316 * scale, cx + 50 * scale, top + 585 * scale), 20f, 20f, paint)

            // Simple flat anatomical landmarks keep the agreed 2D style while making the body readable.
            paint.color = if (front) Color.rgb(205, 82, 91) else Color.rgb(125, 137, 154)
            if (front) {
                c.drawOval(RectF(cx - 40*scale, top + 135*scale, cx - 5*scale, top + 205*scale), paint)
                c.drawOval(RectF(cx + 5*scale, top + 135*scale, cx + 40*scale, top + 205*scale), paint)
                paint.color = Color.rgb(176, 64, 82)
                c.drawCircle(cx, top + 190*scale, 13*scale, paint)
                paint.color = Color.rgb(188, 121, 84)
                c.drawOval(RectF(cx - 34*scale, top + 235*scale, cx + 34*scale, top + 290*scale), paint)
            } else {
                paint.strokeWidth = 6f * scale
                paint.style = Paint.Style.STROKE
                paint.color = Color.rgb(170, 178, 190)
                c.drawLine(cx, top + 120*scale, cx, top + 320*scale, paint)
                paint.style = Paint.Style.FILL
            }

            if (front) {
                zone(c, "Голова", RectF(cx - 37*scale, top + 15*scale, cx + 37*scale, top + 82*scale))
                zone(c, "Шея", RectF(cx - 22*scale, top + 78*scale, cx + 22*scale, top + 116*scale))
                zone(c, "Грудь", RectF(cx - 55*scale, top + 116*scale, cx + 55*scale, top + 215*scale))
                zone(c, "Живот", RectF(cx - 53*scale, top + 210*scale, cx + 53*scale, top + 320*scale))
                zone(c, "Рука", RectF(cx - 105*scale, top + 110*scale, cx - 67*scale, top + 305*scale))
                zone(c, "Рука", RectF(cx + 67*scale, top + 110*scale, cx + 105*scale, top + 305*scale))
                zone(c, "Нога", RectF(cx - 51*scale, top + 315*scale, cx - 7*scale, top + 590*scale))
                zone(c, "Нога", RectF(cx + 7*scale, top + 315*scale, cx + 51*scale, top + 590*scale))
            } else {
                zone(c, "Голова", RectF(cx - 37*scale, top + 15*scale, cx + 37*scale, top + 82*scale))
                zone(c, "Шея", RectF(cx - 22*scale, top + 78*scale, cx + 22*scale, top + 116*scale))
                zone(c, "Спина", RectF(cx - 55*scale, top + 114*scale, cx + 55*scale, top + 220*scale))
                zone(c, "Поясница", RectF(cx - 52*scale, top + 215*scale, cx + 52*scale, top + 320*scale))
                zone(c, "Рука", RectF(cx - 105*scale, top + 110*scale, cx - 67*scale, top + 305*scale))
                zone(c, "Рука", RectF(cx + 67*scale, top + 110*scale, cx + 105*scale, top + 305*scale))
                zone(c, "Нога", RectF(cx - 51*scale, top + 315*scale, cx - 7*scale, top + 590*scale))
                zone(c, "Нога", RectF(cx + 7*scale, top + 315*scale, cx + 51*scale, top + 590*scale))
            }

            paint.color = muted(); paint.textSize = 14f
            val label = if (front) "ПЕРЕД" else "ЗАД"
            c.drawText(label, cx - 20f, h - 20f, paint)
        }

        private fun zone(c: Canvas, name: String, rect: RectF) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (name == selectedZone) 5f else 2f
            paint.color = if (name == selectedZone) accent() else Color.rgb(145, 157, 174)
            c.drawRoundRect(rect, 18f, 18f, paint)
            paint.style = Paint.Style.FILL
            zones.add(BodyZone(name, rect))
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                for (z in zones) {
                    if (z.rect.contains(event.x, event.y)) {
                        selectedZone = z.name
                        invalidate()
                        return true
                    }
                }
            }
            return true
        }
    }

    private fun showPain() {
        base(); setContentView(root)
        root.addView(header("Характер боли"))
        root.addView(text("Выбранная область: $selectedZone", 18f, true))
        root.addView(text("Как именно ощущается боль?", 16f))
        val types = listOf("Ноющая", "Колющая", "Жгучая", "Давящая", "Пульсирующая", "Тянущая")
        for (type in types) root.addView(button(if (type == painType) "●  $type" else "○  $type") { painType = type; showPain() })
        root.addView(text("Сила боли: $painStrength из 10", 18f, true))
        val seek = SeekBar(this).apply { max = 10; progress = painStrength }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, user: Boolean) { painStrength = value; }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(primary("Далее") { showDetails() })
    }

    private fun showDetails() {
        base(); setContentView(root)
        root.addView(header("Подробности"))
        root.addView(text("Область: $selectedZone", 18f, true))
        root.addView(text("Характер: $painType  •  Сила: $painStrength/10", 16f))
        val input = EditText(this).apply {
            hint = "Опишите боль подробнее: когда началась, что усиливает или уменьшает"
            setText(details); minLines = 5; gravity = Gravity.TOP
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 190))
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(primary("Получить рекомендации") { details = input.text.toString(); showRecommendations() })
    }

    private fun showRecommendations() {
        base(); setContentView(root)
        root.addView(header("Рекомендации"))
        root.addView(text("Выбранная область: $selectedZone", 18f, true))
        root.addView(text("Характер: $painType\nСила: $painStrength/10", 16f))
        if (painStrength >= 8) {
            root.addView(text("⚠ Очень сильная боль", 20f, true))
            root.addView(text("При внезапной или очень сильной боли, обмороке, затруднённом дыхании, кровотечении или быстром ухудшении состояния нужна срочная медицинская помощь.", 15f))
        } else {
            root.addView(text("Травы могут быть только дополнительной справочной опцией и не заменяют диагностику причины боли.", 15f))
        }
        root.addView(primary("🌿 Подходящие травы") { showHerbs(selectedZone) })
        root.addView(button("Изменить область") { showBody(front) })
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav())
    }

    private fun showHerbs(filterArea: String) {
        base(); setContentView(root)
        root.addView(header("Каталог трав"))
        root.addView(text(if (filterArea.isBlank()) "Каталог с поиском" else "Для выбранной области: $filterArea", 18f, true))
        val search = EditText(this).apply { hint = "Поиск травы по названию..." }
        root.addView(search)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun fill(query: String) {
            list.removeAllViews()
            val q = query.trim().lowercase(Locale.getDefault())
            val matches = herbs.filter { herb ->
                val areaOk = filterArea.isBlank() || herb.areas.contains(filterArea)
                val textOk = q.isBlank() || herb.name.lowercase(Locale.getDefault()).contains(q) || herb.latin.lowercase(Locale.getDefault()).contains(q)
                areaOk && textOk
            }
            if (matches.isEmpty()) list.addView(text("Ничего не найдено.", 16f))
            matches.forEach { herb ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(10, 8, 10, 8)
                    setBackgroundColor(card())
                }
                card.addView(text("🌿 ${herb.name}", 18f, true))
                card.addView(text(herb.latin, 14f))
                card.addView(text(herb.description, 14f))
                card.setOnClickListener { showHerb(herb, filterArea) }
                list.addView(card, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 5, 0, 5) })
            }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { fill(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        fill("")
        root.addView(bottomNav())
    }

    private fun showHerb(herb: Herb, area: String) {
        base(); setContentView(root)
        root.addView(header(herb.name) { showHerbs(area) })
        root.addView(text(herb.latin, 15f))
        root.addView(text("Описание", 18f, true))
        root.addView(text(herb.description, 16f))
        root.addView(text("Безопасное применение", 18f, true))
        root.addView(text(herb.application, 16f))
        root.addView(text("Ограничения и осторожность", 18f, true))
        root.addView(text(herb.caution, 16f))
        root.addView(text("Важно: при беременности, хронических заболеваниях, приёме лекарств, аллергиях или необычной/сильной боли применение трав лучше согласовать со специалистом.", 14f))
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(primary("← Вернуться к каталогу") { showHerbs(area) })
        root.addView(bottomNav())
    }

    private fun showInfo() {
        base(); setContentView(root)
        root.addView(header("История / сведения"))
        root.addView(text("GdeBolit2D", 25f, true))
        root.addView(text("Плоская анатомическая схема: передняя и задняя стороны, выбор области касанием, характер и сила боли, подробности, рекомендации и каталог трав.", 16f))
        root.addView(text("Справочная информация не заменяет медицинскую консультацию.", 15f))
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav())
    }

    private fun showSettings() {
        base(); setContentView(root)
        root.addView(header("Настройки"))
        root.addView(button(if (dark) "☀  Светлая тема" else "☾  Чёрная тема") { toggleTheme() })
        root.addView(text("Выбранная тема сохраняется на устройстве.", 15f))
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(bottomNav())
    }
}
