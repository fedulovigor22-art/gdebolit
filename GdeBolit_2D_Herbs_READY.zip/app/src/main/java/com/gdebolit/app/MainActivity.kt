package com.gdebolit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769E0)
private val Pink = Color(0xFFFF3B5C)
private val Bg = Color(0xFFF7F9FC)
private val Dark = Color(0xFF14213D)

data class Herb(
    val name: String,
    val uses: String,
    val forms: String,
    val caution: String
)

val herbs = listOf(
    Herb("Ромашка", "Традиционно используют как мягкий успокаивающий и пищеварительный чай.", "чай, настой", "Аллергия на сложноцветные; при беременности и приёме лекарств — уточнить совместимость."),
    Herb("Мята перечная", "Традиционно применяют при ощущении тяжести и спазмах пищеварительного тракта.", "чай, настой", "Может усиливать изжогу; осторожность при желчнокаменной болезни."),
    Herb("Имбирь", "Традиционно используют при тошноте и дискомфорте в желудке.", "чай, пища", "Осторожность при нарушениях свёртывания и приёме антикоагулянтов."),
    Herb("Календула", "Наружно традиционно применяют для ухода за кожей; внутреннее применение требует осторожности.", "наружно, настой", "Не использовать при аллергии на сложноцветные без консультации специалиста."),
    Herb("Мелисса", "Традиционно используют как успокаивающий травяной чай.", "чай, настой", "Может усиливать сонливость при сочетании с седативными средствами."),
    Herb("Шалфей", "Традиционно применяют для полосканий и как травяной настой.", "полоскание, настой", "Не превышать рекомендованные дозы; длительное внутреннее применение без специалиста не рекомендуется.")
)

enum class Screen { HOME, FRONT, BACK, PAIN, INTENSITY, DESCRIPTION, DETAILS, HERBS, RESULT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GdeBolitApp() }
    }
}

@Composable
fun GdeBolitApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedArea by remember { mutableStateOf("Не выбрано") }
    var intensity by remember { mutableStateOf(5) }
    var description by remember { mutableStateOf("Ноющая") }
    var selectedHerbs by remember { mutableStateOf(setOf<String>()) }
    var front by remember { mutableStateOf(true) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Bg,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = screen == Screen.HOME,
                        onClick = { screen = Screen.HOME },
                        icon = { Text("⌂", fontSize = 24.sp) },
                        label = { Text("Главная") }
                    )
                    NavigationBarItem(
                        selected = screen == Screen.RESULT,
                        onClick = { screen = Screen.RESULT },
                        icon = { Text("◷", fontSize = 20.sp) },
                        label = { Text("История") }
                    )
                    NavigationBarItem(
                        selected = screen == Screen.HERBS,
                        onClick = { screen = Screen.HERBS },
                        icon = { Text("✿", fontSize = 20.sp) },
                        label = { Text("Травы") }
                    )
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen { screen = Screen.FRONT }
                    Screen.FRONT, Screen.BACK -> BodyScreen(
                        isFront = screen == Screen.FRONT,
                        onBack = { screen = Screen.HOME },
                        onSwitch = { screen = if (screen == Screen.FRONT) Screen.BACK else Screen.FRONT },
                        onArea = {
                            selectedArea = it
                            front = screen == Screen.FRONT
                            screen = Screen.INTENSITY
                        },
                        front = front
                    )
                    Screen.INTENSITY -> IntensityScreen(
                        intensity = intensity,
                        setIntensity = { intensity = it },
                        onBack = { screen = if (front) Screen.FRONT else Screen.BACK },
                        onNext = { screen = Screen.DESCRIPTION }
                    )
                    Screen.DESCRIPTION -> DescriptionScreen(
                        selected = description,
                        setSelected = { description = it },
                        onBack = { screen = Screen.INTENSITY },
                        onNext = { screen = Screen.DETAILS }
                    )
                    Screen.DETAILS -> DetailsScreen(
                        area = selectedArea,
                        intensity = intensity,
                        description = description,
                        onBack = { screen = Screen.DESCRIPTION },
                        onNext = { screen = Screen.HERBS }
                    )
                    Screen.HERBS -> HerbCatalogScreen(
                        selected = selectedHerbs,
                        onToggle = { name ->
                            selectedHerbs = if (name in selectedHerbs) selectedHerbs - name else selectedHerbs + name
                        },
                        onBack = { screen = Screen.DETAILS },
                        onNext = { screen = Screen.RESULT }
                    )
                    Screen.RESULT -> ResultScreen(
                        area = selectedArea,
                        intensity = intensity,
                        description = description,
                        herbs = selectedHerbs.toList(),
                        onBack = { screen = Screen.HERBS },
                        onHerbs = { screen = Screen.HERBS }
                    )
                }
            }
        }
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Text("‹", fontSize = 38.sp, color = Dark,
                modifier = Modifier.clickable { onBack() }.padding(end = 10.dp))
        }
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Dark)
    }
}

@Composable
fun HomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(22.dp))
        Text("ГдеБолит", Modifier.align(Alignment.CenterHorizontally), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Dark)
        Text("2D выбор точки боли", Modifier.align(Alignment.CenterHorizontally), fontSize = 18.sp, color = Color.Gray)
        Spacer(Modifier.height(26.dp))
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Укажите место боли", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("Выберите вид тела и нажмите на область боли.", color = Color.Gray)
                Spacer(Modifier.height(28.dp))
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Text("Вид спереди")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onStart, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Text("Вид сзади")
                }
            }
        }
        HerbBanner()
    }
}

@Composable
fun HerbBanner() {
    Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text("🌿 Каталог трав", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("После выбора области можно подобрать травы для ознакомления с традиционным применением и мерами предосторожности.",
                color = Color.Gray)
        }
    }
}

@Composable
fun BodyScreen(
    isFront: Boolean,
    onBack: () -> Unit,
    onSwitch: () -> Unit,
    onArea: (String) -> Unit,
    front: Boolean
) {
    val areas = if (isFront)
        listOf("Голова", "Шея", "Грудь", "Живот", "Рука", "Бедро", "Колено", "Голень", "Стопа")
    else
        listOf("Голова", "Шея", "Спина", "Поясница", "Ягодицы", "Рука", "Бедро", "Колено", "Голень", "Стопа")

    Column(Modifier.fillMaxSize()) {
        Header(if (isFront) "Вид спереди" else "Вид сзади", onBack)
        Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            FilterChip(selected = isFront, onClick = { if (!isFront) onSwitch() }, label = { Text("Спереди") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = !isFront, onClick = { if (isFront) onSwitch() }, label = { Text("Сзади") })
        }
        Spacer(Modifier.height(8.dp))
        Card(Modifier.padding(18.dp).fillMaxWidth().weight(1f), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(if (isFront) R.drawable.body_front else R.drawable.body_back),
                    contentDescription = if (isFront) "Вид тела спереди" else "Вид тела сзади",
                    modifier = Modifier.height(260.dp).fillMaxWidth(),
                    contentScale = ContentScale.Fit
                )
                Text("Нажмите на область ниже", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Dark)
                Text("2D интерактивная схема", color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(areas) { area ->
                        OutlinedButton(
                            onClick = { onArea(area) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(area) }
                    }
                }
            }
        }
    }
}

@Composable
fun IntensityScreen(intensity: Int, setIntensity: (Int) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Интенсивность боли", onBack)
        Text("Насколько сильная боль?", Modifier.padding(horizontal = 22.dp), fontSize = 20.sp)
        Spacer(Modifier.height(20.dp))
        Slider(value = intensity.toFloat(), onValueChange = { setIntensity(it.toInt().coerceIn(0,10)) }, valueRange = 0f..10f,
            modifier = Modifier.padding(horizontal = 22.dp))
        Text("Сила боли: $intensity из 10", Modifier.align(Alignment.CenterHorizontally), fontSize = 24.sp)
        Spacer(Modifier.height(30.dp))
        Text(
            when {
                intensity == 0 -> "Нет боли"
                intensity <= 3 -> "Слабая"
                intensity <= 5 -> "Умеренная"
                intensity <= 7 -> "Сильная"
                else -> "Очень сильная"
            },
            Modifier.align(Alignment.CenterHorizontally), fontSize = 22.sp, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.weight(1f))
        Button(onClick = onNext, Modifier.padding(20.dp).fillMaxWidth()) { Text("Далее") }
    }
}

@Composable
fun DescriptionScreen(selected: String, setSelected: (String) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    val options = listOf("Ноющая", "Острая", "Тянущая", "Пульсирующая", "Жгучая", "Давящая")
    Column(Modifier.fillMaxSize()) {
        Header("Описание боли", onBack)
        Text("Как описать вашу боль?", Modifier.padding(horizontal = 22.dp), fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp)) {
            items(options) { option ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp))
                        .background(Color.White).clickable { setSelected(option) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(option, Modifier.weight(1f), fontSize = 17.sp)
                    RadioButton(selected = selected == option, onClick = { setSelected(option) })
                }
            }
        }
        Button(onClick = onNext, Modifier.padding(20.dp).fillMaxWidth()) { Text("Далее") }
    }
}

@Composable
fun DetailsScreen(area: String, intensity: Int, description: String, onBack: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Детали боли", onBack)
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Выбранная область", color = Color.Gray)
                Text(area, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("Интенсивность: $intensity/10")
                Text("Характер: $description")
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Дополнительно", Modifier.padding(horizontal = 20.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        listOf("Когда началась боль?", "Что усиливает боль?", "Что уменьшает боль?", "Есть ли другие симптомы?").forEach {
            Card(Modifier.padding(horizontal = 20.dp, vertical = 5.dp).fillMaxWidth()) {
                Text(it, Modifier.padding(18.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onNext, Modifier.padding(20.dp).fillMaxWidth()) { Text("Перейти к травам") }
    }
}

@Composable
fun HerbCatalogScreen(selected: Set<String>, onToggle: (String) -> Unit, onBack: () -> Unit, onNext: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = herbs.filter { it.name.contains(query, ignoreCase = true) || it.uses.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        Header("Каталог трав", onBack)
        Text("Выберите травы для ознакомления", Modifier.padding(horizontal = 20.dp), fontSize = 19.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.padding(16.dp).fillMaxWidth(),
            label = { Text("Поиск травы") }, singleLine = true)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            items(filtered) { herb ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🌿", fontSize = 24.sp)
                            Spacer(Modifier.width(10.dp))
                            Text(herb.name, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Checkbox(checked = herb.name in selected, onCheckedChange = { onToggle(herb.name) })
                        }
                        Text(herb.uses, color = Color.DarkGray)
                        Text("Форма: ${herb.forms}", fontSize = 13.sp, color = Color.Gray)
                        Text("Важно: ${herb.caution}", fontSize = 13.sp, color = Color(0xFF8A4B08))
                    }
                }
            }
        }
        Button(onClick = onNext, Modifier.padding(16.dp).fillMaxWidth()) {
            Text("Показать выбранные (${selected.size})")
        }
    }
}

@Composable
fun ResultScreen(area: String, intensity: Int, description: String, herbs: List<String>, onBack: () -> Unit, onHerbs: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Рекомендации", onBack)
        Card(Modifier.padding(20.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Результат", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Область: $area")
                Text("Сила: $intensity/10")
                Text("Характер: $description")
                Spacer(Modifier.height(16.dp))
                Text("Выбранные травы", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (herbs.isEmpty()) Text("Пока ничего не выбрано.", color = Color.Gray)
                else herbs.forEach { Text("• $it", Modifier.padding(top = 5.dp)) }
            }
        }
        Card(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Важно", fontWeight = FontWeight.Bold)
                Text("Каталог носит справочный характер и не заменяет диагностику и лечение. При сильной, внезапной или нарастающей боли, травме или тревожных симптомах нужна медицинская помощь.")
            }
        }
        Spacer(Modifier.height(15.dp))
        OutlinedButton(onClick = onHerbs, Modifier.padding(horizontal = 20.dp).fillMaxWidth()) {
            Text("Изменить выбор трав")
        }
        Spacer(Modifier.height(20.dp))
    }
}
