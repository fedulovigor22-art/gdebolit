package com.gdebolit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFFF3D5A)
private val Ink = Color(0xFF14213D)
private val Bg = Color(0xFFF7F8FC)

data class PainRecord(val place: String, val pain: Int, val type: String, val date: String)

enum class Screen { HOME, BODY, QUESTIONS, SYMPTOMS, RESULT, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { GdeBolitApp() } }
}

@Composable fun GdeBolitApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var place by remember { mutableStateOf("Не выбрано") }
    var pain by remember { mutableIntStateOf(5) }
    var type by remember { mutableStateOf("Ноющая") }
    var start by remember { mutableStateOf("Сегодня") }
    var symptoms by remember { mutableStateOf(setOf<String>()) }
    var records by remember { mutableStateOf(listOf<PainRecord>()) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Red, background = Bg)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.HOME -> Home(onNew = { screen = Screen.BODY }, onHistory = { screen = Screen.HISTORY })
                Screen.BODY -> Body(place, onPick = { place = it; screen = Screen.QUESTIONS }, onBack = { screen = Screen.HOME })
                Screen.QUESTIONS -> Questions(pain, { pain = it }, type, { type = it }, start, { start = it }, onNext = { screen = Screen.SYMPTOMS }, onBack = { screen = Screen.BODY })
                Screen.SYMPTOMS -> Symptoms(symptoms, { symptoms = it }, onNext = { screen = Screen.RESULT }, onBack = { screen = Screen.QUESTIONS })
                Screen.RESULT -> Result(place, pain, type, symptoms, onSave = { records = listOf(PainRecord(place,pain,type,"Сегодня")) + records; screen = Screen.HOME }, onBack = { screen = Screen.SYMPTOMS })
                Screen.HISTORY -> History(records, onBack = { screen = Screen.HOME })
            }
        }
    }
}

@Composable fun Header(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) Text("‹", fontSize = 36.sp, color = Ink, modifier = Modifier.clickable { onBack() }.padding(end=12.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}

@Composable fun Home(onNew: () -> Unit, onHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Spacer(Modifier.height(25.dp)); Text("Где болит?", fontSize=38.sp, fontWeight=FontWeight.Bold, color=Ink)
        Text("Покажите на теле — разберёмся, что делать дальше.", fontSize=18.sp, color=Color.Gray, modifier=Modifier.padding(top=8.dp))
        Spacer(Modifier.height(28.dp))
        Card(shape=RoundedCornerShape(28.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFFEFF1FF))) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("🧍", fontSize=100.sp); Text("Покажите, где болит", fontSize=24.sp, fontWeight=FontWeight.Bold, color=Ink)
                Text("Нажмите на область боли", color=Color.Gray, modifier=Modifier.padding(top=6.dp))
                Spacer(Modifier.height(20.dp)); Button(onClick=onNew, colors=ButtonDefaults.buttonColors(containerColor=Red), shape=RoundedCornerShape(18.dp), modifier=Modifier.fillMaxWidth().height(58.dp)) { Text("ПОКАЗАТЬ, ГДЕ БОЛИТ", fontSize=17.sp) }
            }
        }
        Spacer(Modifier.height(18.dp)); OutlinedButton(onClick=onHistory, modifier=Modifier.fillMaxWidth().height(52.dp)) { Text("История записей") }
        Spacer(Modifier.weight(1f)); Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF3FF)), shape=RoundedCornerShape(18.dp)) { Text("Важно: приложение не ставит диагноз и не заменяет врача. При резком ухудшении состояния обращайтесь за медицинской помощью.", modifier=Modifier.padding(16.dp), color=Ink) }
    }
}

@Composable fun Body(place:String,onPick:(String)->Unit,onBack:()->Unit) {
    Column(Modifier.fillMaxSize()) { Header("1. Где болит?", onBack); Text("Выберите область", modifier=Modifier.padding(horizontal=20.dp), color=Color.Gray)
        Spacer(Modifier.height(20.dp));
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text("🧍", fontSize=190.sp)
                Text("Нажмите на нужную область ниже", color=Color.Gray)
                Spacer(Modifier.height(18.dp));
                listOf("Голова","Грудь","Живот","Спина","Рука","Нога").chunked(2).forEach { row -> Row { row.forEach { p -> AssistChip(onClick={onPick(p)}, label={Text(p)}, modifier=Modifier.padding(4.dp)) } } }
            }
        }
    }
}

@Composable fun Questions(pain:Int,setPain:(Int)->Unit,type:String,setType:(String)->Unit,start:String,setStart:(String)->Unit,onNext:()->Unit,onBack:()->Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) { Header("2. Расскажите подробнее", onBack); Text("Как болит?", fontWeight=FontWeight.Bold, color=Ink)
        Row(Modifier.fillMaxWidth().padding(vertical=10.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Ноющая","Колющая","Жгучая","Давящая").forEach { x -> FilterChip(selected=type==x,onClick={setType(x)},label={Text(x)}) } }
        Text("Сила боли: $pain из 10", fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=12.dp), color=Ink); Slider(value=pain.toFloat(),onValueChange={setPain(it.toInt())},valueRange=0f..10f,steps=9)
        Text("Когда началось?", fontWeight=FontWeight.Bold, color=Ink); Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(vertical=10.dp)){listOf("Сегодня","Вчера","2–7 дней назад").forEach{x->FilterChip(selected=start==x,onClick={setStart(x)},label={Text(x)})}}
        Spacer(Modifier.weight(1f)); Button(onClick=onNext,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("ДАЛЕЕ")}
    }
}

@Composable fun Symptoms(selected:Set<String>,setSelected:(Set<String>)->Unit,onNext:()->Unit,onBack:()->Unit){
    val all=listOf("Тошнота","Рвота","Температура","Вздутие","Диарея","Запор","Потеря аппетита","Боль при движении","Боль при нажатии","Другое")
    Column(Modifier.fillMaxSize().padding(20.dp)){Header("3. Дополнительные симптомы",onBack);Text("Выберите всё, что есть",color=Color.Gray);Spacer(Modifier.height(12.dp));LazyColumn(Modifier.weight(1f)){items(all){s->Row(Modifier.fillMaxWidth().clickable{setSelected(if(s in selected) selected-s else selected+s).let{} }.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(s,Modifier.weight(1f),color=Ink);Checkbox(checked=s in selected,onCheckedChange{setSelected(if(it)selected+s else selected-s)})}}};Button(onClick=onNext,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("ПОЛУЧИТЬ РЕЗУЛЬТАТ")}}
}

@Composable fun Result(place:String,pain:Int,type:String,symptoms:Set<String>,onSave:()->Unit,onBack:()->Unit){
    val urgent=pain>=8 || "Температура" in symptoms || "Рвота" in symptoms || "Кровь" in symptoms
    Column(Modifier.fillMaxSize().padding(20.dp)){Header("Результат",onBack);Card(colors=CardDefaults.cardColors(containerColor=if(urgent)Color(0xFFFFE8EA) else Color(0xFFFFF4DE)),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(18.dp)){Text(if(urgent)"Обратите внимание" else "Наблюдайте за состоянием",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink);Text(if(urgent)"При сильной боли или тревожных симптомах лучше обратиться за медицинской помощью." else "Запишите изменения симптомов и при сохранении или усилении боли обратитесь к врачу.",modifier=Modifier.padding(top=8.dp),color=Ink)}}
        Spacer(Modifier.height(18.dp));Text("Ваша запись",fontWeight=FontWeight.Bold,color=Ink);Text("Место: $place\nБоль: $pain/10 · $type\nСимптомы: ${if(symptoms.isEmpty())"нет отмеченных" else symptoms.joinToString()}",modifier=Modifier.padding(top=8.dp),color=Color.DarkGray)
        Spacer(Modifier.weight(1f));Text("Это не диагноз. Не откладывайте обращение за помощью при ухудшении состояния.",color=Color.Gray,fontSize=13.sp);Button(onClick=onSave,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp)){Text("СОХРАНИТЬ ЗАПИСЬ")}
    }
}

@Composable fun History(records:List<PainRecord>,onBack:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Header("История",onBack);if(records.isEmpty())Text("Записей пока нет. Создайте первую запись.",color=Color.Gray,modifier=Modifier.padding(top=20.dp)) else LazyColumn{items(records){r->Card(Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text(r.place,fontWeight=FontWeight.Bold,color=Ink);Text("${r.pain}/10 · ${r.type} · ${r.date}",color=Color.Gray)}}}}}}
