package com.gdebolit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    int d(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    final int RED=Color.rgb(255,61,90), INK=Color.rgb(20,33,61), BG=Color.rgb(247,248,252);
    FrameLayout root; String place="Не выбрано", type="Ноющая", start="Сегодня"; int pain=5; Set<String> symptoms=new LinkedHashSet<>();
    ArrayList<String> history=new ArrayList<>();
    TextView title(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(INK);t.setTextSize(size);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(d(20),d(18),d(20),d(10));return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); GradientDrawable g=new GradientDrawable();g.setColor(RED);g.setCornerRadius(22);b.setBackground(g);return b;}
    TextView info(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.DKGRAY);t.setTextSize(17);t.setPadding(d(20),d(8),d(20),d(12));return t;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(15,20,31));showHome();}
    void base(){root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);}
    void showHome(){base(); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(18),d(22),d(18),d(18));root.addView(l,new FrameLayout.LayoutParams(-1,-1));
        TextView h=title("Где болит?",38);l.addView(h);TextView v=info("3D-версия • интерактивная анатомическая карта");v.setTextColor(RED);v.setTextSize(16);l.addView(v);
        Space sp=new Space(this);l.addView(sp,new LinearLayout.LayoutParams(d(1),d(18)));
        TextView hero=title("РЕАЛИСТИЧНОЕ 3D-ТЕЛО",25);hero.setGravity(Gravity.CENTER);l.addView(hero);
        TextView desc=info("Вращайте человека пальцем, приближайте взглядом и нажимайте прямо на место боли. Внутренние органы отображаются внутри тела.");desc.setGravity(Gravity.CENTER);l.addView(desc);
        Space s2=new Space(this);l.addView(s2,new LinearLayout.LayoutParams(d(1),d(18)));
        Button go=button("▶  ПОКАЗАТЬ, ГДЕ БОЛИТ");go.setOnClickListener(vv->showBody());l.addView(go,new LinearLayout.LayoutParams(-1,d(64)));
        Space s3=new Space(this);l.addView(s3,new LinearLayout.LayoutParams(d(1),d(12)));
        Button hist=new Button(this);hist.setText("История записей");hist.setTextSize(17);hist.setOnClickListener(vv->showHistory());l.addView(hist,new LinearLayout.LayoutParams(-1,d(58)));
        Space s4=new Space(this);l.addView(s4,new LinearLayout.LayoutParams(d(1),0,1));
        TextView warn=info("Важно: приложение не ставит медицинский диагноз. При сильной или внезапной боли, одышке, крови, обмороке или резком ухудшении состояния нужна срочная медицинская помощь.");warn.setBackgroundColor(Color.rgb(232,242,255));l.addView(warn);
    }
    void showBody(){base(); LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);root.addView(col,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL); TextView back=title("‹",38);back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(d(60),d(70)));TextView h=title("1. Где болит?",28);bar.addView(h,new LinearLayout.LayoutParams(0,d(70),1));col.addView(bar);
        TextView sub=info("Крутите 3D-тело пальцем. Нажмите прямо на место боли. Голова, руки, ноги и органы интерактивны.");sub.setTextSize(16);col.addView(sub);
        FrameLayout bodyWrap=new FrameLayout(this);col.addView(bodyWrap,new LinearLayout.LayoutParams(-1,0,1));
        ThreeDBodyView body=new ThreeDBodyView(this,z->{place=z;});bodyWrap.addView(body,new FrameLayout.LayoutParams(-1,-1));
        TextView sel=info("Выбрано: "+place);sel.setTextColor(RED);sel.setTextSize(20);sel.setGravity(Gravity.CENTER);bodyWrap.addView(sel,new FrameLayout.LayoutParams(-1,d(50),Gravity.TOP));
        Button next=button("ПОДТВЕРДИТЬ ОБЛАСТЬ");next.setOnClickListener(v->showQuestions());FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,d(64),Gravity.BOTTOM);np.setMargins(d(18),0,d(18),d(18));bodyWrap.addView(next,np);
        // update selected label by periodic lightweight refresh
        body.setOnTouchListener((v,e)->{boolean r=body.onTouchEvent(e);sel.setText("Выбрано: "+place);return r;});
    }
    void showQuestions(){base();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(18),d(10),d(18),d(18));root.addView(l,new FrameLayout.LayoutParams(-1,-1));
        TextView b=title("‹   2. Расскажите подробнее",27);b.setOnClickListener(v->showBody());l.addView(b);l.addView(info("Как именно ощущается боль?"));
        String[] types={"Ноющая","Колющая","Жгучая","Давящая"};LinearLayout tr=new LinearLayout(this);tr.setOrientation(LinearLayout.HORIZONTAL);for(String x:types){Button q=new Button(this);q.setText(x);q.setTextSize(14);q.setOnClickListener(v->type=x);tr.addView(q,new LinearLayout.LayoutParams(0,d(58),1));}l.addView(tr);
        TextView pv=info("Сила боли: "+pain+" из 10");l.addView(pv);SeekBar sb=new SeekBar(this);sb.setMax(10);sb.setProgress(pain);sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){pain=p;pv.setText("Сила боли: "+pain+" из 10");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});l.addView(sb,new LinearLayout.LayoutParams(-1,d(60)));l.addView(info("Когда началось?"));
        String[] starts={"Сегодня","Вчера","2–7 дней назад"};LinearLayout sr=new LinearLayout(this);for(String x:starts){Button q=new Button(this);q.setText(x);q.setTextSize(13);q.setOnClickListener(v->start=x);sr.addView(q,new LinearLayout.LayoutParams(0,d(58),1));}l.addView(sr);
        Space sp=new Space(this);l.addView(sp,new LinearLayout.LayoutParams(d(1),0,1));Button n=button("ДАЛЕЕ");n.setOnClickListener(v->showSymptoms());l.addView(n,new LinearLayout.LayoutParams(-1,d(64)));
    }
    void showSymptoms(){base();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(18),d(10),d(18),d(18));root.addView(l,new FrameLayout.LayoutParams(-1,-1));TextView b=title("‹   3. Дополнительные симптомы",26);b.setOnClickListener(v->showQuestions());l.addView(b);l.addView(info("Выберите всё, что есть. Текст крупный, на весь экран."));
        String[] all={"Тошнота","Рвота","Температура","Вздутие","Диарея","Запор","Потеря аппетита","Боль при движении","Боль при нажатии","Одышка","Кровь","Головокружение"};LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);l.addView(sv,new LinearLayout.LayoutParams(-1,0,1));for(String s:all){CheckBox c=new CheckBox(this);c.setText(s);c.setTextSize(18);c.setPadding(d(18),d(5),d(10),d(5));c.setChecked(symptoms.contains(s));c.setOnCheckedChangeListener((v,checked)->{if(checked)symptoms.add(s);else symptoms.remove(s);});list.addView(c,new LinearLayout.LayoutParams(-1,d(60)));}
        Button n=button("ПОЛУЧИТЬ РЕЗУЛЬТАТ");n.setOnClickListener(v->showResult());l.addView(n,new LinearLayout.LayoutParams(-1,d(64)));
    }
    void showResult(){base();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(18),d(10),d(18),d(18));root.addView(l,new FrameLayout.LayoutParams(-1,-1));TextView b=title("‹   4. Предварительная оценка",26);b.setOnClickListener(v->showSymptoms());l.addView(b);
        boolean urgent=pain>=8||symptoms.contains("Кровь")||symptoms.contains("Одышка");TextView z=title(urgent?"⚠️ НУЖНА СРОЧНАЯ ОЦЕНКА":"ВОЗМОЖНЫЕ ПРИЧИНЫ",23);z.setTextColor(urgent?Color.rgb(180,30,45):INK);l.addView(z);l.addView(info("Область: "+place+"\nБоль: "+pain+"/10 • "+type+"\nЭто ориентир, а не диагноз."));
        String causes="• Мышечная/суставная причина\n• Воспалительный или функциональный процесс\n• Причина со стороны соответствующего органа — зависит от симптомов\n\nЧто можно сделать:\n• Покой и наблюдение за состоянием.\n• Не перегружать болезненную область.\n• При усилении или сохранении боли обратиться к врачу.";TextView ct=info(causes);ct.setTextSize(18);l.addView(ct);
        Space sp=new Space(this);l.addView(sp,new LinearLayout.LayoutParams(d(1),0,1));Button done=button("ГОТОВО");done.setOnClickListener(v->{history.add(place+" • "+pain+"/10 • "+type);showHome();});l.addView(done,new LinearLayout.LayoutParams(-1,d(64)));
    }
    void showHistory(){base();LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(d(18),d(10),d(18),d(18));root.addView(l,new FrameLayout.LayoutParams(-1,-1));TextView b=title("‹   История",28);b.setOnClickListener(v->showHome());l.addView(b);if(history.isEmpty())l.addView(info("Записей пока нет."));else for(String s:history){TextView t=info("●  "+s);t.setTextSize(18);l.addView(t);}}
}
