# GdeBolit — instructions for GitHub Copilot

Project: Android Java/Kotlin app, module `app`.

## Build environment
- JDK: 17
- Android compileSdk/targetSdk: 35
- Android Gradle Plugin: 8.6.1
- CI Gradle: 8.10.2 (use the existing GitHub Actions setup)

## Rules
1. Do not replace the existing application with a new project.
2. Preserve the current UI and existing functionality unless explicitly requested.
3. Before changing dependencies, inspect `app/build.gradle.kts` and keep the project dependency-light.
4. `ThreeDBodyView.java` uses `float` heavily. Java decimal literals passed to float parameters must have `f` suffix, and Math.* results assigned to float must use an explicit `(float)` cast.
5. After every source change, run `gradle :app:assembleDebug --no-daemon --stacktrace` in CI and fix all compilation errors.
6. Do not stop after explaining an error: make the edit, rebuild, and continue until the APK is produced.
7. Keep the 3D body, rotation, pain-zone selection and internal-organ visualization working.
8. Do not introduce Compose unless explicitly requested.

## Current known fix
`ThreeDBodyView.java` previously had double literals in calls to `capsule(...)` around the arm segments. Those arguments are now explicitly float literals (`0f`).
