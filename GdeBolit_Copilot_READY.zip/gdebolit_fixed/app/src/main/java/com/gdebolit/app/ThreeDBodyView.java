package com.gdebolit.app;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.*;

/** A real-time software 3D anatomical-style renderer: rotatable body + internal organs. */
public class ThreeDBodyView extends View {
    public interface Picker { void pick(String zone); }
    private final Picker picker;
    private final ArrayList<Tri> tris = new ArrayList<>();
    private float rotY = 0f, rotX = 0.04f;
    private float lastX, lastY;
    private boolean moved;
    private String selected = "";
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(7);

    static class V { float x,y,z; V(float x,float y,float z){this.x=x;this.y=y;this.z=z;} }
    static class Tri {
        V a,b,c; int color; int alpha; float depth;
        Tri(V a,V b,V c,int color,int alpha){this.a=a;this.b=b;this.c=c;this.color=color;this.alpha=alpha;}
    }

    public ThreeDBodyView(Context c, Picker p){
        super(c); picker=p; setBackgroundColor(Color.rgb(8,12,20));
        text.setTypeface(Typeface.create("sans",Typeface.BOLD));
        buildModel();
    }

    private int rgb(int r,int g,int b){return Color.rgb(r,g,b);}
    private void ellipsoid(float cx,float cy,float cz,float rx,float ry,float rz,int color,int alpha,int rings,int segs){
        V[][] v=new V[rings+1][segs];
        for(int i=0;i<=rings;i++){
            double ph=-Math.PI/2 + Math.PI*i/rings;
            for(int j=0;j<segs;j++){
                double th=2*Math.PI*j/segs;
                v[i][j]=new V(cx+(float)(rx*Math.cos(ph)*Math.cos(th)),cy+(float)(ry*Math.sin(ph)),cz+(float)(rz*Math.cos(ph)*Math.sin(th)));
            }
        }
        for(int i=0;i<rings;i++) for(int j=0;j<segs;j++){
            V a=v[i][j], b=v[i+1][j], c=v[i+1][(j+1)%segs], d=v[i][(j+1)%segs];
            tris.add(new Tri(a,b,c,color,alpha)); tris.add(new Tri(a,c,d,color,alpha));
        }
    }

    private void capsule(float x1,float y1,float z1,float x2,float y2,float z2,float r,int color,int alpha){
        // cylinder with hemispherical-ish ends, built from rings along the segment
        float ax=x2-x1, ay=y2-y1, az=z2-z1; float len=(float)Math.sqrt(ax*ax+ay*ay+az*az); if(len<.001f)return;
        ax/=len; ay/=len; az/=len;
        float ux=0,uy=1,uz=0; if(Math.abs(ax*ux+ay*uy+az*uz)>.9f){ux=1;uy=0;uz=0;}
        float bx=ay*uz-az*uy, by=az*ux-ax*uz, bz=ax*uy-ay*ux; float bl=(float)Math.sqrt(bx*bx+by*by+bz*bz); bx/=bl;by/=bl;bz/=bl;
        float cx=by*az-bz*ay, cy=bz*ax-bx*az, cz=bx*ay-by*ax;
        int rings=8,segs=12; V[][] vs=new V[rings+1][segs];
        for(int i=0;i<=rings;i++){
            float t=i/(float)rings; float px=x1+ax*len*t, py=y1+ay*len*t, pz=z1+az*len*t;
            float rr=r*(0.94f+0.06f*(float)Math.sin(Math.PI*t));
            for(int j=0;j<segs;j++){double th=2*Math.PI*j/segs; float qx=(float)Math.cos(th), qy=(float)Math.sin(th);
                vs[i][j]=new V(px+rr*(bx*qx+cx*qy),py+rr*(by*qx+cy*qy),pz+rr*(bz*qx+cz*qy));}
        }
        for(int i=0;i<rings;i++)for(int j=0;j<segs;j++){V a=vs[i][j],b=vs[i+1][j],c=vs[i+1][(j+1)%segs],d=vs[i][(j+1)%segs];tris.add(new Tri(a,b,c,color,alpha));tris.add(new Tri(a,c,d,color,alpha));}
        ellipsoid(x1,y1,z1,r,r,r,color,alpha,6,12); ellipsoid(x2,y2,z2,r,r,r,color,alpha,6,12);
    }

    private void tube(List<V> path,float radius,int color,int alpha){
        for(int k=0;k<path.size()-1;k++){
            V p=path.get(k), q=path.get(k+1); capsule(p.x,p.y,p.z,q.x,q.y,q.z,radius,color,alpha);
        }
    }

    private void buildModel(){
        tris.clear();
        int skin=rgb(208,154,132), skinLight=rgb(231,183,161), skinDark=rgb(176,119,102);
        // Main body shell: translucent so organs remain visible.
        ellipsoid(0,1.18f,0,0.48f,0.50f,0.42f,skinLight,112,16,20); // head
        ellipsoid(0,0.48f,0,0.18f,0.22f,0.17f,skin,120,12,16); // neck
        ellipsoid(0,-0.35f,0,0.78f,1.08f,0.40f,skin,82,20,24); // torso
        // Shoulders / arms
        capsule(-0.72f,0.18f,0,-0.93f,-0.72f,0,0.18f,skin,92);
        capsule(0.72f,0.18f,0,0.93f,-0.72f,0,0.18f,skin,92);
        capsule(-0.93f,-0.72f,0f,-0.96f,-1.55f,0f,0.15f,skin,92);
        capsule(0.93f,-0.72f,0f,0.96f,-1.55f,0f,0.15f,skin,92);
        ellipsoid(-0.96f,-1.67f,0,0.16f,0.25f,0.12f,skinLight,100,10,14);
        ellipsoid(0.96f,-1.67f,0,0.16f,0.25f,0.12f,skinLight,100,10,14);
        // Legs and feet
        capsule(-0.34f,-1.10f,0,-0.39f,-2.05f,0,0.25f,skin,95);
        capsule(0.34f,-1.10f,0,0.39f,-2.05f,0,0.25f,skin,95);
        capsule(-0.39f,-2.05f,0,-0.42f,-2.95f,0,0.20f,skin,95);
        capsule(0.39f,-2.05f,0,0.42f,-2.95f,0,0.20f,skin,95);
        ellipsoid(-0.45f,-3.10f,0.10f,0.25f,0.12f,0.42f,skinLight,105,10,14);
        ellipsoid(0.45f,-3.10f,0.10f,0.25f,0.12f,0.42f,skinLight,105,10,14);
        // Face hints
        ellipsoid(-0.16f,1.28f,0.43f,0.055f,0.045f,0.035f,rgb(55,45,45),190,8,10);
        ellipsoid(0.16f,1.28f,0.43f,0.055f,0.045f,0.035f,rgb(55,45,45),190,8,10);
        ellipsoid(0,1.12f,0.43f,0.09f,0.045f,0.055f,skinDark,150,8,10);
        // Chest/abdomen contour pieces
        ellipsoid(-0.27f,0.02f,0.36f,0.31f,0.28f,0.08f,skinLight,105,10,16);
        ellipsoid(0.27f,0.02f,0.36f,0.31f,0.28f,0.08f,skinLight,105,10,16);
        for(int i=0;i<3;i++){
            float y=-0.25f-i*0.28f; ellipsoid(-0.18f,y,0.39f,0.13f,0.10f,0.05f,skinLight,75,8,12); ellipsoid(0.18f,y,0.39f,0.13f,0.10f,0.05f,skinLight,75,8,12);
        }

        // Internal anatomy in front of shell.
        int lung=rgb(224,112,125), lung2=rgb(201,84,102), heart=rgb(182,40,52);
        int liver=rgb(133,66,38), stomach=rgb(232,145,102), kidney=rgb(128,70,70), intestine=rgb(217,94,94), bowel=rgb(235,133,128);
        ellipsoid(-0.30f,0.10f,0.46f,0.30f,0.52f,0.18f,lung,210,14,18);
        ellipsoid(0.30f,0.10f,0.46f,0.30f,0.52f,0.18f,lung,210,14,18);
        ellipsoid(0,0.02f,0.56f,0.22f,0.30f,0.20f,heart,235,14,18);
        ellipsoid(0.28f,-0.62f,0.43f,0.53f,0.27f,0.20f,liver,220,14,18);
        ellipsoid(-0.23f,-0.70f,0.50f,0.34f,0.22f,0.19f,stomach,220,14,18);
        ellipsoid(0.58f,-0.72f,0.48f,0.12f,0.25f,0.12f,kidney,225,12,16);
        ellipsoid(-0.58f,-0.72f,0.48f,0.12f,0.25f,0.12f,kidney,225,12,16);
        // Intestinal loops
        for(int i=0;i<5;i++){
            float y=-1.05f+i*0.18f;
            List<V> p=new ArrayList<>();
            p.add(new V(-0.42f,y,0.52f)); p.add(new V(-0.18f,y+0.10f,0.55f)); p.add(new V(0.10f,y-0.04f,0.56f)); p.add(new V(0.38f,y+0.08f,0.53f));
            tube(p,0.055f,bowel,230);
        }
        // Large bowel frame
        List<V> colon=new ArrayList<>(); colon.add(new V(-0.55f,-0.92f,0.49f)); colon.add(new V(-0.62f,-1.28f,0.48f)); colon.add(new V(-0.38f,-1.45f,0.48f)); colon.add(new V(0.02f,-1.48f,0.48f)); colon.add(new V(0.42f,-1.42f,0.48f)); colon.add(new V(0.58f,-1.18f,0.48f)); colon.add(new V(0.54f,-0.92f,0.49f)); tube(colon,0.10f,intestine,235);
        // Pelvic organ indication
        ellipsoid(0,-1.78f,0.42f,0.16f,0.16f,0.12f,rgb(191,91,103),210,10,14);
    }

    private V rotate(V p){
        float cy=(float)Math.cos(rotY), sy=(float)Math.sin(rotY); float x=p.x*cy+p.z*sy, z=-p.x*sy+p.z*cy;
        float cx=(float)Math.cos(rotX), sx=(float)Math.sin(rotX); float y=p.y*cx-z*sx; z=p.y*sx+z*cx;
        return new V(x,y,z);
    }
    private float projectX(V p,float s,float cx){float d=7.0f; float f=d/(d-p.z); return cx+p.x*s*f;}
    private float projectY(V p,float s,float cy){float d=7.0f; float f=d/(d-p.z); return cy-p.y*s*f;}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); c.drawColor(Color.rgb(8,12,20));
        float w=getWidth(), h=getHeight(); float scale=Math.min(w/5.0f,h/7.0f); float cx=w/2f, cy=h/2f+12*getResources().getDisplayMetrics().density;
        ArrayList<Tri> draw=new ArrayList<>(tris);
        for(Tri t:draw){V a=rotate(t.a),b=rotate(t.b),d=rotate(t.c); t.depth=(a.z+b.z+d.z)/3f;}
        Collections.sort(draw, new Comparator<Tri>(){public int compare(Tri a,Tri b){return Float.compare(a.depth,b.depth);}});
        paint.setStyle(Paint.Style.FILL); paint.setStrokeWidth(1);
        for(Tri t:draw){
            V a=rotate(t.a),b=rotate(t.b),d=rotate(t.c);
            float ax=b.x-a.x, ay=b.y-a.y, az=b.z-a.z, bx=d.x-a.x, by=d.y-a.y, bz=d.z-a.z;
            float nx=ay*bz-az*by, ny=az*bx-ax*bz, nz=ax*by-ay*bx; float nl=(float)Math.sqrt(nx*nx+ny*ny+nz*nz); if(nl<.0001f)continue; nx/=nl;ny/=nl;nz/=nl;
            float light=0.35f+0.65f*Math.max(0,ny*0.35f+nz*0.75f);
            int r=(int)(Color.red(t.color)*light), g=(int)(Color.green(t.color)*light), bcol=(int)(Color.blue(t.color)*light);
            paint.setColor(Color.argb(t.alpha,Math.min(255,r),Math.min(255,g),Math.min(255,bcol)));
            Path p=new Path();p.moveTo(projectX(a,scale,cx),projectY(a,scale,cy));p.lineTo(projectX(b,scale,cx),projectY(b,scale,cy));p.lineTo(projectX(d,scale,cx),projectY(d,scale,cy));p.close();c.drawPath(p,paint);
        }
        // Ground glow
        paint.setColor(Color.argb(70,160,170,190)); c.drawOval(new RectF(cx-125,cy+scale*3.05f,cx+125,cy+scale*3.18f),paint);
        // Selected marker
        if(!selected.isEmpty()){
            text.setTextSize(18*getResources().getDisplayMetrics().scaledDensity); text.setColor(Color.rgb(255,64,91)); text.setTextAlign(Paint.Align.CENTER); c.drawText("●  "+selected,cx,34*getResources().getDisplayMetrics().density,text);
        }
        text.setTextSize(12*getResources().getDisplayMetrics().scaledDensity); text.setColor(Color.LTGRAY); text.setTextAlign(Paint.Align.CENTER); c.drawText("Проведите пальцем — вращение 360°   •   Нажмите — точка боли",cx,h-18*getResources().getDisplayMetrics().density,text);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:lastX=e.getX();lastY=e.getY();moved=false;return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getX()-lastX,dy=e.getY()-lastY; if(Math.abs(dx)+Math.abs(dy)>3)moved=true;
                rotY+=dx*0.012f; rotX+=dy*0.006f; rotX=Math.max(-0.75f,Math.min(0.75f,rotX)); lastX=e.getX();lastY=e.getY();invalidate();return true;
            case MotionEvent.ACTION_UP:
                if(!moved){selected=hit(e.getX(),e.getY()); if(picker!=null)picker.pick(selected);invalidate();} return true;
        }
        return true;
    }

    private String hit(float px,float py){
        float w=getWidth(),h=getHeight(),scale=Math.min(w/5.0f,h/7.0f),cx=w/2f,cy=h/2f+12*getResources().getDisplayMetrics().density;
        float lx=(px-cx)/scale, ly=(cy-py)/scale;
        float cyR=(float)Math.cos(-rotY), syR=(float)Math.sin(-rotY); float x=lx*cyR, z=lx*syR; // approximate inverse
        if(ly>0.85f)return "Голова";
        if(ly>0.15f && Math.abs(x)<0.55f)return "Грудь";
        if(ly>-0.35f && Math.abs(x)<0.62f)return "Живот";
        if(ly>-0.75f && Math.abs(x)<0.62f)return "Кишечник";
        if(ly<-0.72f && Math.abs(x)<0.42f)return "Таз";
        if(x<-0.55f && ly>-0.5f)return "Левая рука";
        if(x>0.55f && ly>-0.5f)return "Правая рука";
        if(x<0)return "Левая нога";
        return "Правая нога";
    }
}
