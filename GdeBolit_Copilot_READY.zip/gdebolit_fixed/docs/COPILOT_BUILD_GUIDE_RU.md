# Инструкция GitHub Copilot для GdeBolit

Репозиторий: `fedulovigor22-art/gdebolit`

## Задача
Исправлять проект прямо в репозитории и доводить GitHub Actions до успешной сборки `app-debug.apk`.

## Окружение
- JDK 17
- Android SDK 35
- Android Gradle Plugin 8.6.1
- Gradle 8.10.2 в GitHub Actions

## Важное исправление
В `app/src/main/java/com/gdebolit/app/ThreeDBodyView.java` методы используют `float`. В Java дробные числа без суффикса `f` являются `double`. Поэтому аргументы методов `capsule(...)` должны быть вида `0f`, `-1.55f` и т.п. Результаты `Math.sin/cos/sqrt` при присваивании в `float` должны иметь `(float)`.

## После изменений
1. Запусти `gradle :app:assembleDebug --no-daemon --stacktrace`.
2. Если появилась новая ошибка — исправь её в файле.
3. Снова запусти сборку.
4. Повторяй до `BUILD SUCCESSFUL`.
5. Убедись, что существует `app/build/outputs/apk/debug/app-debug.apk`.

Не переписывай проект с нуля и не удаляй 3D-тело, вращение, выбор зоны боли или органы.
