plugins { id("com.android.application") }

android {
    namespace = "com.gdebolit.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gdebolit.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.8.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
