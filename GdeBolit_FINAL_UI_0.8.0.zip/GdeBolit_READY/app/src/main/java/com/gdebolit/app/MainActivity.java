package com.gdebolit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    BodyView v;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(247,248,252));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        v=new BodyView(this); setContentView(v);
    }
    @Override public void onBackPressed(){ if(v.page>0){v.page=Math.max(0,v.page-1);v.invalidate();} else super.onBackPressed(); }
}

class BodyView extends View {
    Paint p=new Paint(3), st=new Paint(3); int page=0; float lastX, angle=0; boolean moving;
    String selected="Нажмите на тело", painType="Ноющая", onset="Сегодня"; int pain=5;
    Set<String> symptoms=new LinkedHashSet<>();
    final int BG=Color.rgb(247,248,252), INK=Color.rgb(20,33,61), ACC=Color.rgb(255,55,88);
    final String[] sy={"Тошнота","Рвота","Температура","Вздутие","Диарея","Запор","Потеря аппетита","Боль при движении","Боль при нажатии","Одышка","Кровь","Головокружение"};
    BodyView(Context c){super(c); setBackgroundColor(BG); st.setStyle(Paint.Style.STROKE); st.setStrokeCap(Paint.Cap.ROUND);}
    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?1:0));c.drawText(s,x,y,p);}
    void center(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setTextAlign(Paint.Align.CENTER);text(c,s,x,y,size,color,bold);p.setTextAlign(Paint.Align.LEFT);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);}
    @Override protected void onDraw(Canvas c){super.onDraw(c); if(page==0)home(c); else if(page==1)body(c); else if(page==2)details(c); else if(page==3)syms(c); else if(page==4)result(c); else history(c);}
    void title(Canvas c,String s){text(c,"‹",18,55,46,INK,false);text(c,s,58,48,25,INK,true);}
    void home(Canvas c){
        text(c,"Где болит?",22,58,34,INK,true); text(c,"Интерактивная карта тела",22,90,18,Color.GRAY,false);
        drawHuman(c,true);
        round(c,24,getHeight()-88,getWidth()-24,getHeight()-22,22,ACC); center(c,"НАЧАТЬ — УКАЗАТЬ ГДЕ БОЛИТ",getWidth()/2,getHeight()-48,17,Color.WHITE,true);
    }
    void body(Canvas c){
        title(c,"1. Где болит?"); text(c,"Крутите тело пальцем. Нажмите прямо на место боли.",18,82,17,Color.GRAY,false);
        drawHuman(c,false);
        center(c,"Проведите пальцем ↔  для вращения",getWidth()/2,getHeight()-120,16,Color.GRAY,false);
        center(c,"Выбрано: "+selected,getWidth()/2,getHeight()-91,20,ACC,true);
        round(c,24,getHeight()-70,getWidth()-24,getHeight()-15,19,ACC); center(c,"ПОДТВЕРДИТЬ ОБЛАСТЬ",getWidth()/2,getHeight()-34,16,Color.WHITE,true);
    }
    float bodyTop(){return 105;} float bodyBottom(){return getHeight()-145;}
    float sc(){return Math.min(getWidth()/430f,(bodyBottom()-bodyTop())/800f);}
    float cx(){return getWidth()/2f;}
    float sy(float y){return bodyTop()+y*sc();}
    float sx(float x){float s=sc(), f=.48f+.52f*Math.abs((float)Math.cos(Math.toRadians(angle))); return cx()+x*s*f;}
    void gradOval(Canvas c,RectF r,int base){p.setShader(new RadialGradient(r.centerX()-r.width()*.22f,r.centerY()-r.height()*.22f,r.width()*.75f,new int[]{Color.argb(245,Math.min(255,Color.red(base)+35),Math.min(255,Color.green(base)+25),Math.min(255,Color.blue(base)+25)),base,Color.argb(180,Math.max(0,Color.red(base)-35),Math.max(0,Color.green(base)-35),Math.max(0,Color.blue(base)-35))},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.FILL);c.drawOval(r,p);p.setShader(null);}
    void drawHuman(Canvas c,boolean home){
        float s=sc(); float top=bodyTop(); float bottom=bodyBottom();
        // soft shadow
        p.setColor(Color.argb(45,70,80,100)); c.drawOval(new RectF(cx()-125*s,bottom+5,cx()+125*s,bottom+28),p);
        // silhouette: head, neck, torso
        gradOval(c,new RectF(cx()-48*s,sy(0),cx()+48*s,sy(92)),Color.rgb(210,184,174));
        round(c,cx()-17*s,sy(78),cx()+17*s,sy(132),13*s,Color.rgb(198,169,158));
        p.setColor(Color.argb(210,207,181,171)); c.drawRoundRect(new RectF(cx()-103*s,sy(120),cx()+103*s,sy(520)),55*s,55*s,p);
        // arms and hands
        limb(c,-1,sy(132),sy(395),26*s); limb(c,1,sy(132),sy(395),26*s);
        limb(c,-1,sy(385),sy(555),20*s); limb(c,1,sy(385),sy(555),20*s);
        p.setColor(Color.rgb(199,171,160)); c.drawOval(new RectF(sx(-24)-18*s,sy(535),sx(-24)+18*s,sy(590)),p); c.drawOval(new RectF(sx(24)-18*s,sy(535),sx(24)+18*s,sy(590)),p);
        // legs and feet
        limb(c,-1,sy(500),sy(690),34*s); limb(c,1,sy(500),sy(690),34*s);
        limb(c,-1,sy(675),sy(805),27*s); limb(c,1,sy(675),sy(805),27*s);
        p.setColor(Color.rgb(196,168,157));c.drawOval(new RectF(cx()-73*s,sy(790),cx()-5*s,sy(825)),p);c.drawOval(new RectF(cx()+5*s,sy(790),cx()+73*s,sy(825)),p);
        // organs with stronger 3D shading
        float f=.45f+.55f*Math.abs((float)Math.cos(Math.toRadians(angle)));
        int a=(int)(95+150*f);
        organ(c,-45,175,90,Color.rgb(216,112,128),a); organ(c,45,175,90,Color.rgb(216,112,128),a);
        organ(c,0,205,58,Color.rgb(190,48,62),a);
        organ(c,25,282,105,Color.rgb(142,72,44),a);
        organ(c,-22,290,68,Color.rgb(238,153,102),a);
        organ(c,55,295,30,Color.rgb(108,68,68),a);
        // kidneys
        organ(c,-54,350,30,Color.rgb(142,74,73),a); organ(c,54,350,30,Color.rgb(142,74,73),a);
        // intestine as thick looped path
        st.setColor(Color.argb(a,205,75,83));st.setStrokeWidth(23*s*f);st.setStyle(Paint.Style.STROKE);
        Path q=new Path();q.moveTo(cx()-62*s,sy(350));q.cubicTo(cx()-88*s,sy(410),cx()-60*s,sy(465),cx()-10*s,sy(455));q.cubicTo(cx()+35*s,sy(485),cx()+78*s,sy(430),cx()+62*s,sy(350));c.drawPath(q,st);
        st.setColor(Color.argb(a,241,142,137));st.setStrokeWidth(12*s*f);Path q2=new Path();q2.moveTo(cx()-47*s,sy(400));q2.cubicTo(cx()-15*s,sy(370),cx()-12*s,sy(450),cx()+12*s,sy(405));q2.cubicTo(cx()+38*s,sy(370),cx()+48*s,sy(435),cx()+17*s,sy(450));c.drawPath(q2,st);
        // spine / vessels for anatomical feel
        st.setColor(Color.argb((int)(60+90*f),125,70,75));st.setStrokeWidth(4*s);c.drawLine(cx(),sy(135),cx(),sy(515),st);
        // front highlight gives volume
        st.setColor(Color.argb(110,255,255,255));st.setStrokeWidth(5*s);c.drawLine(cx()-55*s,sy(130),cx()-72*s,sy(505),st);
        if(moving&&!home) center(c,"Поворот: "+(((int)angle%360)+360)%360+"°",cx(),bodyBottom()+38,13,Color.DKGRAY,false);
    }
    void limb(Canvas c,float side,float y1,float y2,float w){float x=sx(side*94);p.setColor(Color.rgb(205,177,165));c.drawRoundRect(new RectF(x-w,y1,x+w,y2),w,w,p);}
    void organ(Canvas c,float x,float y,float size,int col,int alpha){float s=sc();float ox=sx(x), oy=sy(y);p.setShader(new RadialGradient(ox-size*s*.2f,oy-size*s*.2f,size*s,new int[]{Color.argb(alpha,Math.min(255,Color.red(col)+30),Math.min(255,Color.green(col)+25),Math.min(255,Color.blue(col)+25)),Color.argb(alpha,Color.red(col),Color.green(col),Color.blue(col)),Color.argb(alpha/2,Math.max(0,Color.red(col)-35),Math.max(0,Color.green(col)-35),Math.max(0,Color.blue(col)-35))},null,Shader.TileMode.CLAMP));c.drawOval(new RectF(ox-size*s*.55f,oy-size*s*.62f,ox+size*s*.55f,oy+size*s*.62f),p);p.setShader(null);}
    void details(Canvas c){
        title(c,"2. Описание боли"); text(c,"Укажите характер боли",20,95,19,INK,true);
        String[] ts={"Ноющая","Колющая","Жгучая","Давящая"};for(int i=0;i<4;i++){float l=18+i*101;round(c,l,112,l+94,164,14,painType.equals(ts[i])?ACC:Color.WHITE);center(c,ts[i],l+47,145,14,painType.equals(ts[i])?Color.WHITE:INK,false);}
        text(c,"Сила боли: "+pain+" / 10",20,205,19,INK,true);st.setStrokeWidth(9);st.setColor(Color.LTGRAY);c.drawLine(30,242,getWidth()-30,242,st);p.setColor(ACC);c.drawCircle(30+(getWidth()-60)*pain/10f,242,13,p);
        text(c,"Когда началась?",20,302,19,INK,true);String[] os={"Сегодня","Вчера","2–7 дней"};for(int i=0;i<3;i++){float l=18+i*132;round(c,l,320,l+123,372,14,onset.equals(os[i])?ACC:Color.WHITE);center(c,os[i],l+61,353,14,onset.equals(os[i])?Color.WHITE:INK,false);}
        round(c,24,getHeight()-70,getWidth()-24,getHeight()-15,19,ACC);center(c,"ДАЛЕЕ",getWidth()/2,getHeight()-34,17,Color.WHITE,true);
    }
    void syms(Canvas c){title(c,"3. Дополнительные симптомы");text(c,"Отметьте все подходящие симптомы",18,86,18,Color.GRAY,false);float y=108;for(String s:sy){round(c,15,y,getWidth()-15,y+51,10,Color.WHITE);text(c,s,30,y+33,18,INK,false);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor(symptoms.contains(s)?ACC:Color.GRAY);c.drawRect(getWidth()-53,y+13,getWidth()-29,y+37,p);if(symptoms.contains(s)){st.setColor(ACC);st.setStrokeWidth(3);c.drawLine(getWidth()-49,y+25,getWidth()-42,y+32,st);c.drawLine(getWidth()-42,y+32,getWidth()-33,y+18,st);}y+=57;}round(c,24,getHeight()-70,getWidth()-24,getHeight()-15,19,ACC);center(c,"ПОЛУЧИТЬ РЕЗУЛЬТАТ",getWidth()/2,getHeight()-34,16,Color.WHITE,true);}
    void result(Canvas c){title(c,"4. Предварительная оценка");text(c,"Область: "+selected,20,92,20,INK,true);text(c,"Боль: "+pain+"/10 • "+painType,20,122,18,Color.DKGRAY,false);boolean urgent=pain>=8||symptoms.contains("Кровь")||symptoms.contains("Одышка");round(c,18,145,getWidth()-18,urgent?255:235,18,urgent?Color.rgb(255,231,234):Color.rgb(255,244,220));text(c,urgent?"ВНИМАНИЕ":"Возможные причины",32,182,21,INK,true);text(c,urgent?"Нужна срочная медицинская оценка при": "Это ориентир, а не диагноз.",32,214,15,INK,false);text(c,urgent?"сильной боли, одышке, крови или ухудшении.":"Причину определяют по осмотру и симптомам.",32,238,15,INK,false);
        text(c,"Что можно сделать",20,292,21,INK,true);text(c,"• Покой и наблюдение за состоянием.",28,326,16,Color.DKGRAY,false);text(c,"• Не перегружать болезненную область.",28,358,16,Color.DKGRAY,false);text(c,"• При усилении или сохранении боли — обратиться к врачу.",28,390,15,Color.DKGRAY,false);round(c,24,getHeight()-70,getWidth()-24,getHeight()-15,19,ACC);center(c,"ГОТОВО",getWidth()/2,getHeight()-34,17,Color.WHITE,true);}
    void history(Canvas c){title(c,"История");text(c,"Здесь будут сохранённые результаты.",20,105,18,Color.GRAY,false);}
    @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==0){lastX=x;moving=false;return true;}if(e.getAction()==2){if(page==1&&Math.abs(x-lastX)>2){angle+= (x-lastX)*.75f;lastX=x;moving=true;invalidate();}return true;}if(e.getAction()==1){
        if(page==0){if(y>getHeight()-120){page=1;invalidate();}return true;}
        if(page==1){if(y<75&&x<55){page=0;invalidate();return true;}if(!moving){selected=hit(x,y);invalidate();}if(y>getHeight()-85&& !selected.equals("Нажмите на тело")){page=2;invalidate();}return true;}
        if(page==2){if(y<75&&x<55){page=1;invalidate();return true;}if(y>105&&y<175){int i=(int)((x-18)/101);if(i>=0&&i<4)painType=new String[]{"Ноющая","Колющая","Жгучая","Давящая"}[i];}else if(y>215&&y<275){pain=Math.max(0,Math.min(10,Math.round((x-30)/(getWidth()-60)*10)));}else if(y>315&&y<390){int i=(int)((x-18)/132);if(i>=0&&i<3)onset=new String[]{"Сегодня","Вчера","2–7 дней"}[i];}else if(y>getHeight()-90)page=3;invalidate();return true;}
        if(page==3){if(y<75&&x<55){page=2;invalidate();return true;}if(y>100&&y<800){int i=(int)((y-108)/57);if(i>=0&&i<sy.length){String z=sy[i];if(symptoms.contains(z))symptoms.remove(z);else symptoms.add(z);invalidate();}}else if(y>getHeight()-90){page=4;invalidate();}return true;}
        if(page==4){if(y<75&&x<55){page=3;invalidate();return true;}if(y>getHeight()-90){page=0;selected="Нажмите на тело";invalidate();}return true;}
        if(page==5&&y<75&&x<55){page=0;invalidate();}return true;}return true;}
    String hit(float px,float py){float s=sc();float f=.48f+.52f*Math.abs((float)Math.cos(Math.toRadians(angle)));float lx=(px-cx())/(s*f), yy=(py-bodyTop())/s;if(yy<100)return "Голова";if(yy<155)return "Шея";if(Math.abs(lx)>105&&yy<420)return lx<0?"Левая рука":"Правая рука";if(yy<245&&Math.abs(lx)<82){if(yy<220)return "Лёгкие";return "Сердце";}if(yy<345&&lx>10)return "Печень";if(yy<355&&lx<10)return "Желудок";if(yy<520&&Math.abs(lx)<85)return "Кишечник";if(yy>515&&Math.abs(lx)<80)return "Таз";if(yy>500)return lx<0?"Левая нога":"Правая нога";return "Грудь";}
}
