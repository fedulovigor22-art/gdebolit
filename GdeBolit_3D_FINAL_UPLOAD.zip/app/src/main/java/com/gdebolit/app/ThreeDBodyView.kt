package com.gdebolit.app

import android.content.Context
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import kotlin.math.cos
import kotlin.math.sin

class ThreeDBodyView(context: Context, private val onPick: (String) -> Unit) : GLSurfaceView(context) {
    private val renderer3d = HumanRenderer(onPick)
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer3d)
        renderMode = RENDERMODE_CONTINUOUSLY
        setBackgroundColor(Color.rgb(247,248,252))
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; moved=false; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx=e.x-downX
                if (kotlin.math.abs(dx)>3 || kotlin.math.abs(e.y-downY)>3) moved=true
                renderer3d.rotationY += dx*0.7f
                downX=e.x; downY=e.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) renderer3d.pick(e.x,e.y,width,height)
                return true
            }
        }
        return true
    }
}

private class HumanRenderer(private val onPick: (String)->Unit) : GLSurfaceView.Renderer {
    var rotationY=0f
    private val vp=FloatArray(16); private val proj=FloatArray(16); private val view=FloatArray(16); private val model=FloatArray(16)
    private lateinit var body: Mesh
    private lateinit var head: Mesh
    private lateinit var heart: Mesh
    private lateinit var lungs: Mesh
    private lateinit var stomach: Mesh
    private lateinit var liver: Mesh
    private lateinit var bowel: Mesh
    private var w=1; private var h=1
    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, c: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
        val vs="attribute vec3 aPos; uniform mat4 uMvp; void main(){gl_Position=uMvp*vec4(aPos,1.0);}"
        val fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"
        body=Mesh(vs,fs); head=Mesh(vs,fs); heart=Mesh(vs,fs); lungs=Mesh(vs,fs); stomach=Mesh(vs,fs); liver=Mesh(vs,fs); bowel=Mesh(vs,fs)
    }
    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, width:Int,height:Int){w=width;h=height;GLES20.glViewport(0,0,width,height);Matrix.perspectiveM(proj,0,45f,width.toFloat()/height,2f,20f)}
    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        GLES20.glClearColor(0.969f,0.973f,0.988f,1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setLookAtM(view,0,0f,0.1f,6.3f,0f,0f,0f,0f,1f,0f)
        Matrix.multiplyMM(vp,0,proj,0,view,0)
        drawHuman()
    }
    private fun base(tx:Float,ty:Float,tz:Float,sx:Float,sy:Float,sz:Float){Matrix.setIdentityM(model,0);Matrix.translateM(model,0,tx,ty,tz);Matrix.rotateM(model,0,rotationY,0f,1f,0f);Matrix.scaleM(model,0,sx,sy,sz)}
    private fun drawHuman(){
        // back silhouette / torso
        base(0f,0f,0f,1.0f,1.55f,0.52f); body.draw(vp,model,floatArrayOf(0.84f,0.56f,0.43f,0.72f))
        base(0f,1.9f,0f,0.42f,0.42f,0.42f); head.draw(vp,model,floatArrayOf(0.86f,0.63f,0.50f,0.88f))
        base(-1.32f,0f,0f,0.28f,1.35f,0.28f); body.draw(vp,model,floatArrayOf(0.86f,0.60f,0.47f,0.86f))
        base(1.32f,0f,0f,0.28f,1.35f,0.28f); body.draw(vp,model,floatArrayOf(0.86f,0.60f,0.47f,0.86f))
        base(-0.48f,-2.0f,0f,0.34f,1.55f,0.36f); body.draw(vp,model,floatArrayOf(0.86f,0.60f,0.47f,0.9f))
        base(0.48f,-2.0f,0f,0.34f,1.55f,0.36f); body.draw(vp,model,floatArrayOf(0.86f,0.60f,0.47f,0.9f))
        // internal organs, shifted forward so they remain visible through torso
        base(0f,0.65f,0.55f,0.36f,0.42f,0.20f); heart.draw(vp,model,floatArrayOf(0.88f,0.12f,0.20f,1f))
        base(-0.43f,0.72f,0.48f,0.32f,0.52f,0.16f); lungs.draw(vp,model,floatArrayOf(0.55f,0.78f,0.88f,1f))
        base(0.43f,0.72f,0.48f,0.32f,0.52f,0.16f); lungs.draw(vp,model,floatArrayOf(0.55f,0.78f,0.88f,1f))
        base(-0.15f,-0.05f,0.55f,0.42f,0.30f,0.22f); stomach.draw(vp,model,floatArrayOf(0.95f,0.55f,0.12f,1f))
        base(0.42f,0.10f,0.50f,0.55f,0.30f,0.18f); liver.draw(vp,model,floatArrayOf(0.55f,0.30f,0.12f,1f))
        base(0f,-0.55f,0.56f,0.62f,0.28f,0.14f); bowel.draw(vp,model,floatArrayOf(0.90f,0.72f,0.15f,1f))
    }
    fun pick(x:Float,y:Float,width:Int,height:Int){
        // screen-space organ map; rotation changes perceived horizontal location.
        val nx=x/width*2f-1f; val ny=1f-y/height*2f
        val c=cos(Math.toRadians(rotationY.toDouble())).toFloat()
        val sx=nx/(0.55f+0.45f*kotlin.math.abs(c))
        val name=when {
            ny>0.15f && ny<0.55f && sx>-0.28f && sx<0.28f -> "Сердце"
            ny>0.10f && ny<0.48f && kotlin.math.abs(sx)<0.58f -> "Лёгкие"
            ny>-0.05f && ny<0.22f && sx<-0.02f -> "Желудок"
            ny>-0.08f && ny<0.25f && sx>0.02f -> "Печень"
            ny>-0.45f && ny<0.02f && kotlin.math.abs(sx)<0.65f -> "Кишечник"
            ny>0.55f -> "Голова"
            ny>-0.65f && ny<0.45f && sx<-0.62f -> "Левая рука"
            ny>-0.65f && ny<0.45f && sx>0.62f -> "Правая рука"
            ny<-0.40f && sx<0f -> "Левая нога"
            ny<-0.40f && sx>=0f -> "Правая нога"
            ny>0.15f -> "Грудь"
            else -> "Живот"
        }
        onPick(name)
    }
}

private class Mesh(vs:String,fs:String){
    private val program:Int; private val pos:Int; private val color:Int; private val mvp:Int; private val buf:java.nio.FloatBuffer
    init {
        program=GLES20.glCreateProgram(); val v=compile(GLES20.GL_VERTEX_SHADER,vs); val f=compile(GLES20.GL_FRAGMENT_SHADER,fs); GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program)
        pos=GLES20.glGetAttribLocation(program,"aPos");color=GLES20.glGetUniformLocation(program,"uColor");mvp=GLES20.glGetUniformLocation(program,"uMvp")
        val verts=ArrayList<Float>(); val stacks=14; val slices=18
        for(i in 0..stacks){val p=Math.PI*i/stacks; val sp=sin(p).toFloat(); val cp=cos(p).toFloat(); for(j in 0..slices){val t=2*Math.PI*j/slices;verts.add((sp*cos(t)).toFloat());verts.add(cp);verts.add((sp*sin(t)).toFloat())}}
        val arr=FloatArray(verts.size){verts[it]};buf=java.nio.ByteBuffer.allocateDirect(arr.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();buf.put(arr).position(0)
    }
    fun draw(vp:FloatArray,model:FloatArray,c:FloatArray){val out=FloatArray(16);Matrix.multiplyMM(out,0,vp,0,model,0);GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(mvp,1,false,out,0);GLES20.glUniform4fv(color,1,c,0);GLES20.glEnableVertexAttribArray(pos);buf.position(0);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,buf);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,buf.capacity()/3);GLES20.glDisableVertexAttribArray(pos)}
    private fun compile(type:Int,src:String):Int{val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s}
}
