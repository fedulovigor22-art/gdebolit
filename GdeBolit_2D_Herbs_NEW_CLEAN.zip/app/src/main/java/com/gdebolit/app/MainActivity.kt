package com.gdebolit.app

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import android.content.Context
import kotlin.math.min

data class Herb(val name:String, val latin:String, val uses:String, val safe:String)
data class Zone(val id:String, val title:String, val front:Boolean, val rect:RectF)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var dark = false
    private var screen = 0
    private var front = true
    private var selectedZone = "Живот"
    private var painType = "Ноющая"
    private var painStrength = 5

    private val herbs = listOf(
        Herb("Ромашка", "Matricaria chamomilla", "Лёгкие спазмы ЖКТ, вздутие.", "Обычно как чай; не использовать при аллергии на сложноцветные."),
        Herb("Мята перечная", "Mentha × piperita", "Диспепсия, ощущение спазма.", "Чай/настой. Осторожно при рефлюксе; не заменяет диагностику."),
        Herb("Мелисса", "Melissa officinalis", "Лёгкое нервное напряжение и функциональный дискомфорт.", "Настой в обычных пищевых количествах."),
        Herb("Имбирь", "Zingiber officinale", "Тошнота, лёгкий желудочный дискомфорт.", "Пищевые количества или чай; осторожно при приёме антикоагулянтов."),
        Herb("Шалфей", "Salvia officinalis", "Полоскания при дискомфорте в горле.", "Не использовать большие дозы эфирного масла внутрь."),
        Herb("Календула", "Calendula officinalis", "Наружный уход за кожей.", "Только наружное применение при отсутствии аллергии."),
        Herb("Тысячелистник", "Achillea millefolium", "Традиционно при лёгком пищеварительном дискомфорте.", "Не использовать при беременности без врача; возможна аллергия."),
        Herb("Липа", "Tilia cordata", "Тёплый напиток при простуде и дискомфорте в горле.", "Как обычный травяной чай.")
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
        }
        root.setBackgroundColor(if (dark) Color.rgb(12,16,23) else Color.rgb(247,248,250))
        return root
    }

    private fun text(s:String, size:Float, bold:Boolean=false): TextView =
        TextView(this).apply {
            text=s; textSize=size; setTextColor(if(dark) Color.WHITE else Color.rgb(18,29,54))
            if(bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0,8,0,8)
        }

    private fun button(s:String, action:()->Unit): Button =
        Button(this).apply {
            text=s; setOnClickListener{action()}
            isAllCaps=false
        }

    private fun header(title:String): LinearLayout {
        val h=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val back=button("‹"){ if(screen==0){} else showHome() }
        h.addView(back, LinearLayout.LayoutParams(60,60))
        h.addView(text(title,24,true), LinearLayout.LayoutParams(0,60,1f))
        h.addView(button(if(dark) "☀" else "☾"){dark=!dark; refresh()}, LinearLayout.LayoutParams(60,60))
        return h
    }

    private fun showHome(){ screen=0; root=base(); setContentView(root)
        root.addView(text("ГдеБолит",32,true))
        root.addView(text("Выберите место боли на плоской анатомической схеме",17))
        root.addView(button("Вид спереди"){showBody(true)})
        root.addView(button("Вид сзади"){showBody(false)})
        root.addView(Space(this), LinearLayout.LayoutParams(1,0,1f))
        root.addView(button("🌿 Каталог трав"){showHerbs("")})
        root.addView(button("История / сведения"){showInfo()})
    }

    private fun showBody(isFront:Boolean){
        front=isFront; screen=1; root=base(); setContentView(root)
        root.addView(header(if(front) "Вид спереди" else "Вид сзади"))
        root.addView(text("Нажмите прямо на область, где болит",17))
        val v=BodyView(this)
        root.addView(v, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(button("Каталог трав"){showHerbs(selectedZone)})
    }

    inner class BodyView(c:Context): View(c){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private val zones = mutableListOf<Zone>()
        override fun onDraw(canvas:Canvas){
            super.onDraw(canvas)
            val w=width.toFloat(); val h=height.toFloat()
            p.color=if(dark) Color.rgb(20,26,35) else Color.WHITE
            canvas.drawRoundRect(10f,10f,w-10f,h-10f,28f,28f,p)
            val cx=w/2f; val top=55f; val scale=min(w/360f,h/650f)
            fun rr(l:Float,t:Float,r:Float,b:Float,color:Int,id:String,title:String){
                p.color=color; val x=RectF(cx+l*scale,top+t*scale,cx+r*scale,top+b*scale)
                canvas.drawRoundRect(x,18f,18f,p); zones.add(Zone(id,title,front,x))
            }
            // Flat anatomical silhouette: head, neck, torso, arms, legs.
            p.color=Color.rgb(238,198,173); canvas.drawCircle(cx,top+55*scale,34*scale,p)
            p.color=Color.rgb(225,178,150); canvas.drawRoundRect(cx-18*scale,top+82*scale,cx+18*scale,top+112*scale,12f,12f,p)
            rr(-72,112,72,265,Color.rgb(224,108,91),"chest","Грудь")
            rr(-66,235,66,350,Color.rgb(225,150,91),"abdomen","Живот")
            rr(-112,118,-72,295,Color.rgb(238,198,173),"armL","Левая рука")
            rr(72,118,112,295,Color.rgb(238,198,173),"armR","Правая рука")
            rr(-55,345,-8,575,Color.rgb(238,198,173),"legL","Левая нога")
            rr(8,345,55,575,Color.rgb(238,198,173),"legR","Правая нога")
            if(!front){
                rr(-62,112,62,230,Color.rgb(151,103,94),"back","Спина")
                rr(-58,225,58,350,Color.rgb(183,122,88),"lower","Поясница")
            } else {
                rr(-55,155,55,235,Color.rgb(195,80,72),"chest2","Грудь")
            }
            // Labels
            p.color=if(dark) Color.WHITE else Color.rgb(50,60,78); p.textSize=15f
            canvas.drawText(if(front) "СПЕРЕДИ" else "СЗАДИ",cx-42,top+625*scale,p)
            // Clear/rebuild hit zones on every draw.
        }
        override fun onTouchEvent(e:MotionEvent):Boolean{
            if(e.action==MotionEvent.ACTION_UP){
                // Recreate same geometry by asking draw; use nearest semantic region.
                val y=e.y
                val center=width/2f
                selectedZone = when {
                    y < height*.20f -> "Голова"
                    y < height*.30f -> "Шея"
                    y < height*.45f -> if(front) "Грудь" else "Спина"
                    y < height*.62f -> if(front) "Живот" else "Поясница"
                    y < height*.78f -> "Бедро"
                    else -> "Нога"
                }
                showPain()
                return true
            }
            return true
        }
    }

    private fun showPain(){
        screen=2; root=base(); setContentView(root)
        root.addView(header("2. Характер и сила боли"))
        root.addView(text("Область: $selectedZone",20,true))
        root.addView(text("Как именно ощущается боль?",17))
        val types=listOf("Ноющая","Колющая","Жгучая","Давящая","Пульсирующая","Тянущая")
        types.forEach{ t ->
            val b=button(if(t==painType) "● $t" else "○ $t"){painType=t; refreshPain()}
            root.addView(b)
        }
        root.addView(text("Сила боли: $painStrength из 10",18,true))
        val seek=SeekBar(this).apply{max=10;progress=painStrength;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){painStrength=p; root.findViewWithTag<TextView>("strength")?.text="Сила боли: $painStrength из 10"}
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })}
        root.addView(seek)
        root.addView(Space(this), LinearLayout.LayoutParams(1,0,1f))
        root.addView(button("Далее"){showDetails()})
    }

    private fun refreshPain(){showPain()}

    private fun showDetails(){
        screen=3; root=base(); setContentView(root)
        root.addView(header("3. Подробности"))
        root.addView(text("Область: $selectedZone",19,true))
        root.addView(text("Характер: $painType\nСила: $painStrength/10",17))
        val input=EditText(this).apply{hint="Что усиливает или уменьшает боль?";setTextColor(if(dark)Color.WHITE else Color.DKGRAY)}
        root.addView(input)
        val start=EditText(this).apply{hint="Когда началось?";setTextColor(if(dark)Color.WHITE else Color.DKGRAY)}
        root.addView(start)
        root.addView(Space(this), LinearLayout.LayoutParams(1,0,1f))
        root.addView(button("Получить рекомендации"){showRecommendations()})
        root.addView(button("🌿 Подобрать травы"){showHerbs(selectedZone)})
    }

    private fun showRecommendations(){
        screen=4; root=base(); setContentView(root)
        root.addView(header("4. Рекомендации"))
        root.addView(text("По выбранной области: $selectedZone",20,true))
        if(painStrength>=8){
            root.addView(text("⚠ Очень сильная боль",21,true))
            root.addView(text("При внезапной или сильной боли, ухудшении состояния, обмороке, затруднённом дыхании, кровотечении или других тревожных симптомах нужна срочная медицинская помощь.",16))
        } else {
            root.addView(text("Наблюдайте за симптомами и не используйте травы как замену диагностике.",16))
        }
        root.addView(button("🌿 Подходящие травы"){showHerbs(selectedZone)})
        root.addView(button("Назад к выбору области"){showBody(front)})
    }

    private fun showHerbs(query:String){
        screen=5; root=base(); setContentView(root)
        root.addView(header("🌿 Каталог трав"))
        root.addView(text(if(query.isBlank()) "Поиск и описание трав" else "Травы для области: $query",20,true))
        val search=EditText(this).apply{hint="Поиск травы";setTextColor(if(dark)Color.WHITE else Color.DKGRAY);setHintTextColor(Color.GRAY)}
        root.addView(search)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this); scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        fun fill(q:String){
            list.removeAllViews()
            herbs.filter{it.name.contains(q,true)||it.latin.contains(q,true)||it.uses.contains(q,true)}
                .forEach{h->
                    val b=button("🌿 ${h.name}\n${h.uses}"){showHerb(h)}
                    list.addView(b)
                }
        }
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fill(s?.toString().orEmpty())}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        fill(query)
    }

    private fun showHerb(h:Herb){
        screen=6; root=base(); setContentView(root)
        root.addView(header(h.name))
        root.addView(text(h.latin,16))
        root.addView(text("Для чего традиционно используется",19,true))
        root.addView(text(h.uses,16))
        root.addView(text("Безопасное применение",19,true))
        root.addView(text(h.safe,16))
        root.addView(text("Важно: травы могут иметь противопоказания и взаимодействия с лекарствами. При сильной, новой или непонятной боли сначала нужна оценка причины.",15))
        root.addView(button("← К каталогу трав"){showHerbs("")})
    }

    private fun showInfo(){
        root=base();setContentView(root)
        root.addView(header("О приложении"))
        root.addView(text("ГдеБолит 2D",26,true))
        root.addView(text("Новая версия полностью построена вокруг плоской анатомической схемы: спереди/сзади, выбор области касанием, характер и сила боли, подробности, рекомендации и каталог трав.",16))
        root.addView(button("🌿 Каталог трав"){showHerbs("")})
    }

    private fun refresh(){
        when(screen){
            0 -> showHome()
            1 -> showBody(front)
            2 -> showPain()
            else -> showHome()
        }
    }
}
